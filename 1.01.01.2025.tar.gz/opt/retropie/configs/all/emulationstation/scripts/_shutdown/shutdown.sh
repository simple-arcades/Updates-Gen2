#!/bin/bash
if [ $(cat /home/pi/music_settings/music_over_games/onoff.flag) == "0" ]; then
        pkill -STOP mpg123
fi

omxplayer -b "/opt/retropie/configs/all/emulationstation/scripts/videos/shutdown.mp4" > /dev/null &
sleep 3s