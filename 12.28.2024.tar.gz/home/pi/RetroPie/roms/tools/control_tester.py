import os
import pygame
from pygame.locals import *
from pygame.math import Vector2
from collections import deque
import time

# Hide Pygame support prompt
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

# -------------------------------------------------------------------
#    USER-CONFIGURABLE FLAGS
# -------------------------------------------------------------------
# 1) Whether to skip drawing the last button in each row (index 3 & 7)
#    for Players 3 and 4. (Player numbering is 0-based in code:
#    Player 3 => joystick_id = 2, Player 4 => joystick_id = 3)
SKIP_EXTRA_BUTTONS_ON_P3_P4 = True

# 2) Enable/disable trackball trails, joystick trails, and button trails
TRACKBALL_TRAIL = True
JOYSTICK_TRAIL = True
BUTTON_TRAIL = True
# -------------------------------------------------------------------

# Initialize Pygame
pygame.init()
pygame.joystick.init()

# Screen settings
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080
FPS = 60
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), HWSURFACE | DOUBLEBUF | SCALED)
pygame.display.set_caption("Multi-Joystick and Trackball Test")
pygame.mouse.set_visible(False)

# Paths
ASSET_PATHS = {
    "background_image": "/home/pi/RetroPie/roms/tools/images/background.jpg",
    "font": "/home/pi/RetroPie/roms/tools/fonts/TinyUnicode.ttf",
    "button_active": "/home/pi/RetroPie/roms/tools/images/button_active.png",
    "button_inactive": "/home/pi/RetroPie/roms/tools/images/button_inactive.png",
    "joystick_idle": "/home/pi/RetroPie/roms/tools/images/joystick_idle.png",
    "joystick_active": "/home/pi/RetroPie/roms/tools/images/joystick_active.png",
    "trackball_indicator": "/home/pi/RetroPie/roms/tools/images/trackball_indicator.png",
    "background_music": "/home/pi/RetroPie/roms/tools/sounds/background_music.mp3",
    "button_press_sound": "/home/pi/RetroPie/roms/tools/sounds/button_press.wav",
    "joystick_move_sound": "/home/pi/RetroPie/roms/tools/sounds/joystick_move.wav",
}

# Preloaded assets and static settings
ASSETS = {}
COLORS = {"background": (0, 0, 0), "text": (255, 255, 255), "not_detected": (100, 100, 100)}
GRID_COLS = 2
FONT_SIZE = 36
BUTTON_SPACING = 70
TRACKBALL_RADIUS = 80
EXIT_HOLD_TIME = 3
joystick_horizontal_adjustment = -120
joystick_vertical_centering = -60
top_row_offset_y = -90
bottom_row_offset_y = top_row_offset_y + BUTTON_SPACING
center_buttons_offset = [(BUTTON_SPACING * 2.5, -200), (BUTTON_SPACING * 3.5, -200)]

# User-configurable fade duration in seconds
FADE_DURATION = 0.3

# User-configurable starting opacity for the trail
STARTING_OPACITY = 50  # Value between 0 and 255

# Maximum number of trail entries
MAX_TRAIL_LENGTH = 25

# Deques for trails
trail_positions = deque(maxlen=MAX_TRAIL_LENGTH)  # Trackball trail
joystick_trail_positions = [deque(maxlen=MAX_TRAIL_LENGTH) for _ in range(4)]  # Joystick trails
button_trail_positions = [[deque(maxlen=MAX_TRAIL_LENGTH) for _ in range(10)] for _ in range(4)]  # Button trails

def preload_assets():
    global ASSETS
    try:
        background_image = pygame.image.load(ASSET_PATHS["background_image"]).convert()
        ASSETS["background_image"] = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error as e:
        print(f"Warning: Failed to load background image. {e}")
        ASSETS["background_image"] = None

    try:
        ASSETS["font"] = pygame.font.Font(ASSET_PATHS["font"], FONT_SIZE)
    except pygame.error as e:
        print(f"Warning: Failed to load font. {e}")
        ASSETS["font"] = pygame.font.Font(None, FONT_SIZE)

    try:
        ASSETS["button_active"] = pygame.image.load(ASSET_PATHS["button_active"]).convert_alpha()
        ASSETS["button_inactive"] = pygame.image.load(ASSET_PATHS["button_inactive"]).convert_alpha()
        ASSETS["joystick_idle"] = pygame.image.load(ASSET_PATHS["joystick_idle"]).convert_alpha()
        ASSETS["joystick_active"] = pygame.image.load(ASSET_PATHS["joystick_active"]).convert_alpha()
        ASSETS["trackball_indicator"] = pygame.image.load(ASSET_PATHS["trackball_indicator"]).convert_alpha()
    except pygame.error as e:
        print(f"Error: Failed to load one or more image assets. {e}")
        pygame.quit()
        exit(1)

    try:
        pygame.mixer.init()
        pygame.mixer.music.load(ASSET_PATHS["background_music"])
        ASSETS["button_press_sound"] = pygame.mixer.Sound(ASSET_PATHS["button_press_sound"])
        ASSETS["joystick_move_sound"] = pygame.mixer.Sound(ASSET_PATHS["joystick_move_sound"])
    except pygame.error as e:
        print(f"Error: Failed to load sounds or music. {e}")
        pygame.quit()
        exit(1)

def play_background_music():
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

def play_sound_effect(sound_key):
    if sound_key in ASSETS:
        ASSETS[sound_key].play()

def draw_background():
    if ASSETS["background_image"]:
        screen.blit(ASSETS["background_image"], (0, 0))

def initialize_joysticks():
    joysticks = []
    for i in range(pygame.joystick.get_count()):
        joystick = pygame.joystick.Joystick(i)
        joystick.init()
        joysticks.append(joystick)
    return joysticks

# Detect if any mouse device is active (trackball/spinner)
trackball_found = pygame.mouse.get_focused()

def update_trackball_position(trackball_pos, last_mouse_pos):
    current_mouse_pos = Vector2(pygame.mouse.get_pos())
    center = Vector2(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    movement = current_mouse_pos - last_mouse_pos

    deadzone = 0.0
    if movement.length() < deadzone:
        movement = Vector2(0, 0)

    trackball_pos.x += movement.x
    trackball_pos.y += movement.y

    if trackball_pos.distance_to(center) > TRACKBALL_RADIUS:
        direction = (trackball_pos - center).normalize()
        trackball_pos = center + direction * TRACKBALL_RADIUS

    pygame.mouse.set_pos(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    return trackball_pos, Vector2(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

def draw_inverted_trail(positions):
    current_time = time.time()
    for entry in list(positions):
        if len(entry) == 2:
            pos, timestamp = entry
            mode = None
        else:
            pos, timestamp, mode = entry

        elapsed_time = current_time - timestamp
        if elapsed_time > FADE_DURATION:
            continue

        alpha = max(0, STARTING_OPACITY * (1 - elapsed_time / FADE_DURATION))

        if mode == 'joystick_active':
            base_image = ASSETS["joystick_active"]
        elif mode == 'active_to_idle':
            # Button released: fade from active to idle
            ratio = elapsed_time / FADE_DURATION
            active_img = ASSETS["button_active"]
            idle_img = ASSETS["button_inactive"]
            blended = pygame.Surface(active_img.get_size(), pygame.SRCALPHA)
            for x in range(active_img.get_width()):
                for y in range(active_img.get_height()):
                    active_px = active_img.get_at((x, y))
                    idle_px = idle_img.get_at((x, y))
                    r = int(active_px.r * (1 - ratio) + idle_px.r * ratio)
                    g = int(active_px.g * (1 - ratio) + idle_px.g * ratio)
                    b = int(active_px.b * (1 - ratio) + idle_px.b * ratio)
                    a = int(active_px.a * (1 - ratio) + idle_px.a * ratio)
                    blended.set_at((x, y), (r, g, b, a))
            base_image = blended
        else:
            base_image = ASSETS["joystick_active"]

        inverted_indicator = pygame.Surface(base_image.get_size(), pygame.SRCALPHA)
        for x in range(base_image.get_width()):
            for y in range(base_image.get_height()):
                pixel = base_image.get_at((x, y))
                inverted_pixel = (255 - pixel.r, 255 - pixel.g, 255 - pixel.b, pixel.a)
                inverted_indicator.set_at((x, y), inverted_pixel)

        inverted_indicator.fill((255, 255, 255, int(alpha)), special_flags=pygame.BLEND_RGBA_MULT)
        screen.blit(inverted_indicator, inverted_indicator.get_rect(center=(pos.x, pos.y)))

    while positions and (time.time() - positions[0][1]) > FADE_DURATION:
        positions.popleft()

def draw_trackball_with_trail(trackball_pos, trail_positions):
    if TRACKBALL_TRAIL:
        current_time = time.time()
        trail_positions.append((trackball_pos.copy(), current_time))

        for pos, timestamp in list(trail_positions):
            elapsed_time = time.time() - timestamp
            if elapsed_time > FADE_DURATION:
                continue

            alpha = max(0, STARTING_OPACITY * (1 - elapsed_time / FADE_DURATION))
            indicator = ASSETS["trackball_indicator"].copy()

            inverted_indicator = pygame.Surface(indicator.get_size(), pygame.SRCALPHA)
            for x in range(indicator.get_width()):
                for y in range(indicator.get_height()):
                    pixel = indicator.get_at((x, y))
                    inverted_pixel = (255 - pixel.r, 255 - pixel.g, 255 - pixel.b, pixel.a)
                    inverted_indicator.set_at((x, y), inverted_pixel)

            inverted_indicator.fill((255, 255, 255, int(alpha)), special_flags=pygame.BLEND_RGBA_MULT)
            screen.blit(inverted_indicator, inverted_indicator.get_rect(center=(pos.x, pos.y)))

        while trail_positions and (time.time() - trail_positions[0][1]) > FADE_DURATION:
            trail_positions.popleft()

    # Draw current trackball position
    screen.blit(
        ASSETS["trackball_indicator"],
        ASSETS["trackball_indicator"].get_rect(center=(trackball_pos.x, trackball_pos.y)),
    )

    # About 150px above the center
    if trackball_found:
        trackball_text = "Trackball or Spinner"
    else:
        # UPDATED TEXT
        trackball_text = "Trackball/Spinner Not Found"

    label = ASSETS["font"].render(trackball_text, True, COLORS["text"])
    screen.blit(label, (SCREEN_WIDTH//2 - label.get_width()//2,
                        (SCREEN_HEIGHT//2 - label.get_height()//2) - 150))

def draw_joystick(joystick_id, grid_x, grid_y, joystick_data=None, joystick_states=None):
    """
    joystick_id = 0-based.  (0=>P1, 1=>P2, 2=>P3, 3=>P4)
    grid_x, grid_y => for positioning on the 2x2 grid
    joystick_data => ( (x_axis, y_axis), [button0, button1, ..., button9] )
    joystick_states => dictionary to store button states, offsets, etc.
    """
    cell_width = SCREEN_WIDTH // GRID_COLS
    cell_height = SCREEN_HEIGHT // GRID_COLS
    cell_center_x = grid_x * cell_width + cell_width // 2 - 50
    cell_center_y = grid_y * cell_height + cell_height // 2 + 100

    current_time = time.time()

    if joystick_data:
        joystick_pos, button_states = joystick_data
        jx_off = joystick_horizontal_adjustment
        jy_off = joystick_vertical_centering

        # Joystick movement logic
        is_active = abs(joystick_pos[0]) > 0.1 or abs(joystick_pos[1]) > 0.1
        if is_active:
            jx_off += int(joystick_pos[0] * 30)
            jy_off += int(joystick_pos[1] * 30)

        if "last_active_offset" not in joystick_states:
            joystick_states["last_active_offset"] = (0, 0)
        old_offset = joystick_states["last_active_offset"]
        new_offset = (jx_off, jy_off) if is_active else (0, 0)

        # Check transitions for sound effects
        if is_active and old_offset == (0, 0):
            play_sound_effect("joystick_move_sound")
        elif is_active and new_offset != old_offset and old_offset != (0,0):
            play_sound_effect("joystick_move_sound")

        # Handle joystick trails
        if JOYSTICK_TRAIL:
            if old_offset == (0, 0) and is_active:
                joystick_states["last_active_offset"] = new_offset
            elif is_active and new_offset != old_offset and old_offset != (0,0):
                ox, oy = old_offset
                joystick_trail_positions[joystick_id].append(
                    (Vector2(cell_center_x + ox, cell_center_y + oy), current_time, 'joystick_active')
                )
                joystick_states["last_active_offset"] = new_offset
            elif not is_active and old_offset != (0,0):
                ox, oy = old_offset
                joystick_trail_positions[joystick_id].append(
                    (Vector2(cell_center_x + ox, cell_center_y + oy), current_time, 'joystick_active')
                )
                joystick_states["last_active_offset"] = (0,0)

            # Draw existing joystick trail
            if joystick_trail_positions[joystick_id]:
                draw_inverted_trail(joystick_trail_positions[joystick_id])

        # Choose joystick image
        joystick_image = ASSETS["joystick_active"] if is_active else ASSETS["joystick_idle"]
        screen.blit(joystick_image, joystick_image.get_rect(center=(cell_center_x + jx_off, cell_center_y + jy_off)))

        # Build offsets for the 8 main buttons + 2 top buttons
        button_offsets = [
            (BUTTON_SPACING, top_row_offset_y),        # index 0
            (BUTTON_SPACING * 2, top_row_offset_y),    # index 1
            (BUTTON_SPACING * 3, top_row_offset_y),    # index 2
            (BUTTON_SPACING * 4, top_row_offset_y),    # index 3
            (BUTTON_SPACING, bottom_row_offset_y),     # index 4
            (BUTTON_SPACING * 2, bottom_row_offset_y), # index 5
            (BUTTON_SPACING * 3, bottom_row_offset_y), # index 6
            (BUTTON_SPACING * 4, bottom_row_offset_y), # index 7
        ]
        button_offsets += center_buttons_offset  # index 8,9

        # Draw/update each button
        for idx, offset in enumerate(button_offsets):
            # ------------------------------------------------------------
            #    OPTIONALLY SKIP for P3/P4, button indexes 3 and 7
            # ------------------------------------------------------------
            if SKIP_EXTRA_BUTTONS_ON_P3_P4 and joystick_id in [2, 3] and idx in [3, 7]:
                # Skip drawing these two buttons for players 3 & 4
                continue

            button_x = cell_center_x + offset[0]
            button_y = cell_center_y + offset[1]

            # Check if the button has just been pressed or released
            if button_states and button_states[idx] and not joystick_states["buttons"][idx]:
                # Pressed
                joystick_states["buttons"][idx] = True
                play_sound_effect("button_press_sound")
            elif button_states and not button_states[idx] and joystick_states["buttons"][idx]:
                # Released
                joystick_states["buttons"][idx] = False
                if BUTTON_TRAIL:
                    button_trail_positions[joystick_id][idx].append(
                        (Vector2(button_x, button_y), current_time, 'active_to_idle')
                    )

            # Choose the correct button image
            if button_states and button_states[idx]:
                button_image = ASSETS["button_active"]
            else:
                button_image = ASSETS["button_inactive"]

            # Draw the button
            screen.blit(button_image, button_image.get_rect(center=(button_x, button_y)))

        # Draw button trails after everything
        if BUTTON_TRAIL:
            for idx, offset in enumerate(button_offsets):
                if SKIP_EXTRA_BUTTONS_ON_P3_P4 and joystick_id in [2, 3] and idx in [3, 7]:
                    continue
                if button_trail_positions[joystick_id][idx]:
                    draw_inverted_trail(button_trail_positions[joystick_id][idx])

    else:
        # No joystick_data => Not detected
        label = ASSETS["font"].render(f"Player {joystick_id + 1} Not Detected", True, COLORS["not_detected"])
        screen.blit(label, (cell_center_x - label.get_width() // 2, cell_center_y - label.get_height() // 2))

def main():
    preload_assets()
    joysticks = initialize_joysticks()
    joystick_states = [
        {"x_moved": False, "y_moved": False, "buttons": [False] * 10}
        for _ in range(len(joysticks))
    ]

    play_background_music()
    trackball_pos = Vector2(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    last_mouse_pos = Vector2(pygame.mouse.get_pos())
    buttons_held_start = [None] * len(joysticks)
    running = True

    if "background_image" in ASSETS and ASSETS["background_image"]:
        draw_background()
        pygame.display.flip()

    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False

        trackball_pos, last_mouse_pos = update_trackball_position(trackball_pos, last_mouse_pos)

        if "background_image" in ASSETS and ASSETS["background_image"]:
            draw_background()

        # Draw up to 4 joystick grids
        for i in range(4):
            grid_x = i % GRID_COLS
            grid_y = i // GRID_COLS
            if i < len(joysticks):
                joystick = joysticks[i]
                joystick_data = (
                    (joystick.get_axis(0), joystick.get_axis(1)),
                    [joystick.get_button(b) for b in range(10)],
                )

                # Check if the user is holding down button 9 and 10 (indexes 8 and 9)
                # to exit the program
                if joystick_data[1][8] and joystick_data[1][9]:
                    if buttons_held_start[i] is None:
                        buttons_held_start[i] = time.time()
                    elif time.time() - buttons_held_start[i] >= EXIT_HOLD_TIME:
                        running = False
                else:
                    buttons_held_start[i] = None

                draw_joystick(i, grid_x, grid_y, joystick_data, joystick_states[i])
            else:
                # Player not connected
                draw_joystick(i, grid_x, grid_y, None)

        # Draw the trackball/spinner
        draw_trackball_with_trail(trackball_pos, trail_positions)

        # Copyright
        copyright_text = "Copyright (c) 2024 Simple Arcades"
        font = ASSETS["font"]
        text_surface = font.render(copyright_text, True, COLORS["text"])
        text_rect = text_surface.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 10))
        screen.blit(text_surface, text_rect)

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
