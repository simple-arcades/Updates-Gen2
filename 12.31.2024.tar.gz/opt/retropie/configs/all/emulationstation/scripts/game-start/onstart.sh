#!/bin/bash

# Path to the mute sound flag file
MUTE_FLAG="/home/pi/music_settings/mute_launch_sound.flag"

# Default mute status (0 = sound on, 1 = sound muted)
MUTE_STATUS=$(cat "$MUTE_FLAG" 2>/dev/null || echo "0")

# Play the launch video with or without sound
if [[ "$MUTE_STATUS" == "1" ]]; then
    # Play video with muted audio
    omxplayer -b --adev local --vol -6000 "/opt/retropie/configs/all/emulationstation/scripts/videos/loading.mp4" > /dev/null &
else
    # Play video with audio
    omxplayer -b --adev local "/opt/retropie/configs/all/emulationstation/scripts/videos/loading.mp4" > /dev/null &
fi

# Start the saved state watcher
#/home/pi/RetroPie/custom_scripts/save_state_watcher.sh > /dev/null 2>&1 &

# Stop the music player
pkill -STOP mpg123