#!/bin/bash
omxplayer -b "/opt/retropie/configs/all/emulationstation/scripts/videos/exit.mp4" > /dev/null &

#pkill -f "/home/pi/RetroPie/custom_scripts/save_state_watcher.sh" > /dev/null 2>&1 &

if [[ $(cat /home/pi/music_settings/onoff.flag) == "1" ]]
then
    pkill -CONT mpg123
fi
