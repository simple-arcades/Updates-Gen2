#!/bin/bash

LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/remote_access.log"
TIMER_PID_FILE="/home/pi/RetroPie/custom_scripts/logs/session_timer.pid"

log_action() {
    echo "$(date): $1" >> "$LOG_FILE"
}

check_dependencies() {
    if ! command -v lsof &> /dev/null; then
        log_action "lsof not found. Installing now."
        sudo apt-get update && sudo apt-get install -y lsof
        if [ $? -eq 0 ]; then
            log_action "lsof successfully installed."
        else
            log_action "Failed to install lsof. Please check the internet connection."
            whiptail --msgbox "Could not install a required tool (lsof). Please check your internet connection and try again." 20 60
            exit 1
        fi
    fi
}

fetch_external_ip() {
    curl -s https://api.ipify.org || echo "Unable to fetch external IP"
}

get_external_connection_info() {
    EXTERNAL_IP=$(fetch_external_ip)
    INTERNAL_IP=$(hostname -I | awk '{print $1}')
    echo -e "Internal IP: $INTERNAL_IP\nExternal IP: $EXTERNAL_IP\nPort: 2222"
}

start_disconnect_timer() {
    sleep $((30 * 60)) && {
        sudo pkill -f "ssh"
        log_action "Session automatically disconnected after 30 minutes."
    } &
    echo $! > "$TIMER_PID_FILE"
}

stop_disconnect_timer() {
    if [ -f "$TIMER_PID_FILE" ]; then
        kill "$(cat "$TIMER_PID_FILE")" 2>/dev/null
        rm -f "$TIMER_PID_FILE"
    fi
}

start_support_session() {
    CONNECTION_INFO=$(get_external_connection_info)

    whiptail --msgbox "Your arcade's remote support session is ready:\n\n$CONNECTION_INFO\n\n\
Share this information with your tech agent. For safety, this session will close automatically after 30 minutes." 20 60

    start_disconnect_timer

    if sudo lsof -i :22 | grep -q ESTABLISHED; then
        whiptail --msgbox "The tech agent is now connected to your arcade and may make adjustments.\n\n\
Please avoid playing games or turning off your arcade during this session. For safety, this session will close automatically after 30 minutes or you can close your session manually by pressing 'Disconnect Session'." 20 60
    else
        log_action "No active connections detected."
        whiptail --msgbox "No active connection detected. Please wait for the tech agent to connect." 20 60
    fi
}

disconnect_support_session() {
    stop_disconnect_timer

    ACTIVE_SESSIONS=$(sudo lsof -i :22 | grep ESTABLISHED | awk '{print $2}')
    if [ -n "$ACTIVE_SESSIONS" ]; then
        for SESSION in $ACTIVE_SESSIONS; do
            sudo kill -9 "$SESSION"
            log_action "Terminated session with PID: $SESSION"
        done
    else
        log_action "No active sessions to terminate."
    fi

    sudo systemctl restart ssh
    log_action "SSH service restarted."

    whiptail --msgbox "The remote support session has ended. The tech agent is now disconnected.\n\n\
Thank you for allowing remote support. Press 'OK' to return to the main menu." 20 60
}

show_port_forwarding_instructions() {
    CONNECTION_INFO=$(get_external_connection_info)

    whiptail --msgbox "To enable remote support:\n\n\
1. Access your router's admin page (refer to your router's manual for instructions).\n\
2. Configure port forwarding as follows:\n\
   - External Port: 2222\n\
   - Internal Port: 22\n\
   - Internal IP: $(hostname -I | awk '{print $1}')\n\
3. Share the following details with your tech agent:\n\n$CONNECTION_INFO" 20 60
}

main_menu() {
    check_dependencies

    whiptail --title "Simple Arcades Remote Support Tool" --msgbox "Welcome to the Simple Arcades Remote Support Tool.\n\n\
This tool allows our tech support team to remotely troubleshoot your arcade. \
Only start a remote session if you have already spoken with a tech agent.\n\n\
For security, unsolicited connections are not monitored." 20 60

    while true; do
        CHOICE=$(whiptail --title "Remote Support Menu" --menu "Choose an option:" 20 60 5 \
        "1" "Start Remote Support Session" \
        "2" "End Support Session" \
        "3" "Port Forwarding Instructions" \
        "4" "View Session Logs" \
        "5" "Exit" 3>&1 1>&2 2>&3)
        
        case $CHOICE in
            1) start_support_session ;;
            2) disconnect_support_session ;;
            3) show_port_forwarding_instructions ;;
            4) whiptail --textbox "$LOG_FILE" 20 60 ;;
            5) stop_disconnect_timer; break ;;
            *) whiptail --msgbox "Invalid option. Please try again." 10 40 ;;
        esac
    done
}

main_menu