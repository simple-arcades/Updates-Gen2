#!/bin/bash

# Paths
HOW_TO_VIDEOS_FOLDER="/home/pi/RetroPie/docs/videos"
LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/user_resources.log"

# Helper Functions
show_message() {
    # Just an OK button for informational messages
    dialog --ok-button "OK" --msgbox "$1" 10 50
}

safe_exit() {
    show_message "Exiting User Resources Menu. Enjoy your arcade!"
    exit 0
}

log_error() {
    echo "$(date): $1" >> "$LOG_FILE"
}

# View User Manual Link
view_user_manual() {
    show_message "View your arcade's manual at: https://www.simple-arcades.com/users-manual/"
}

# Play How-To Videos
play_how_to_videos() {
    if [[ ! -d "$HOW_TO_VIDEOS_FOLDER" ]]; then
        log_error "How-to videos folder not found at $HOW_TO_VIDEOS_FOLDER."
        show_message "How-to videos folder not found. Please contact support."
        return
    fi

    local MENU_OPTIONS=()
    local COUNTER=1
    for video in "$HOW_TO_VIDEOS_FOLDER"/*.mp4; do
        [[ -f "$video" ]] || continue
        MENU_OPTIONS+=("$COUNTER" "$(basename "${video%.*}")")
        ((COUNTER++))
    done

    if [[ ${#MENU_OPTIONS[@]} -eq 0 ]]; then
        log_error "No videos found in $HOW_TO_VIDEOS_FOLDER."
        show_message "How-to videos coming soon!"
        return
    fi

    # No "Back" menu option. User presses Cancel to go back.
    local OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "How-To Videos" --menu "Select a video to play:" 15 50 ${#MENU_OPTIONS[@]} "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

    if [[ $? -ne 0 ]]; then
        # User pressed Cancel
        return
    fi

    local SELECTED_VIDEO="${MENU_OPTIONS[((OPTION-1)*2)+1]}"
    clear
    omxplayer "$HOW_TO_VIDEOS_FOLDER/$SELECTED_VIDEO.mp4"
    if [[ $? -ne 0 ]]; then
        log_error "Failed to play video: $SELECTED_VIDEO."
        show_message "An error occurred while playing the video. Please contact support."
        return
    fi

    read -n 1 -s -r -p "Press any button to return to the menu..."
    clear
}

# User Resources Menu
user_resources_menu() {
    while true; do
        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "User Resources" --menu "Choose an option:" 15 50 3 \
            1 "View User Manual" \
            2 "Play How-To Videos" \
            3 "Exit" \
            3>&1 1>&2 2>&3)

        if [[ $? -ne 0 ]]; then
            # User pressed Cancel at the top level menu, which can also exit
            safe_exit
        fi

        case $OPTION in
            1) view_user_manual ;;
            2) play_how_to_videos ;;
            3) safe_exit ;;
            *) safe_exit ;;
        esac
    done
}

# Start Menu
user_resources_menu
