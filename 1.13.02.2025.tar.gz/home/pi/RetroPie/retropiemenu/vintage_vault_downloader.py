#!/usr/bin/env python3
import os
import sys
import argparse
import json
import requests
import shutil
import zipfile
import xml.etree.ElementTree as ET
import subprocess
import traceback
import psutil
import fnmatch
import datetime
import string
import math

ROMS_DIR = '/home/pi/RetroPie/roms'
PASSWORD = "iagree"
VERBOSE = False
IMAGES_SUBDIR = 'media/images'
VIDEOS_SUBDIR = 'media/videos'

# --------------------------------------------------------------------
# NEW: DRY_RUN FEATURE
# --------------------------------------------------------------------
# If True, the script simulates downloads and installations
# (shows the gauge, logs actions) but does NOT actually write files,
# copy anything, or modify gamelist.xml.
DRY_RUN = True  # Set to False to actually download/install
# --------------------------------------------------------------------

def show_msgbox(message, height=10, width=50, title="Message"):
    subprocess.run(['dialog', '--msgbox', message, str(height), str(width)], stdin=open('/dev/tty'))

def ask_yes_no(question, title="Confirmation", height=10, width=50):
    dialog_args = [
        'dialog','--stdout','--title',title,'--yesno',question,str(height),str(width)
    ]
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    return (result.returncode == 0)

def get_input_from_osk(title, prompt):
    dialog_args = ['dialog','--stdout','--title',title,'--inputbox',prompt,'10','50']
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    if result.returncode != 0:
        return ""
    return result.stdout.strip()

def password_prompt(prompt, attempts=3):
    for i in range(attempts):
        pwd = get_input_from_osk("Password Required", prompt)
        if pwd == PASSWORD:
            return True
        else:
            if i < attempts - 1:
                show_msgbox(f"Incorrect password. {attempts - i - 1} attempt(s) remaining.")
    show_msgbox("Incorrect password entered too many times. No changes made.")
    return False

def get_disk_usage(path):
    usage = psutil.disk_usage(path)
    return usage.used, usage.free, usage.total

def format_size(bytes_size):
    for unit in ['B','KB','MB','GB','TB']:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} PB"

def show_storage_usage():
    used,free,total = get_disk_usage(ROMS_DIR)
    msg=(
        f"Current Storage Usage:\n\n"
        f"Used: {format_size(used)}\n"
        f"Free: {format_size(free)}\n"
        f"Total: {format_size(total)}"
    )
    show_msgbox(msg)

def load_manifest(manifest_url=None, manifest_path=None):
    if manifest_url:
        r = requests.get(manifest_url)
        r.raise_for_status()
        data = r.json()
        return data
    elif manifest_path:
        with open(manifest_path,'r',encoding='utf-8') as f:
            data = json.load(f)
        return data
    else:
        show_msgbox("No manifest source specified.")
        sys.exit(1)

def list_systems(manifest):
    systems = manifest.get('systems', [])
    return systems

def parse_gamelist_for_installed(system_name):
    system_dir = os.path.join(ROMS_DIR, system_name)
    gl_path = os.path.join(system_dir, 'gamelist.xml')
    installed_names = set()
    if os.path.exists(gl_path):
        try:
            tree = ET.parse(gl_path)
            root = tree.getroot()
            for g in root.findall('game'):
                n = g.find('name')
                if n is not None and n.text:
                    installed_names.add(n.text.strip().lower())
        except:
            pass
    return installed_names

def select_system(systems):
    if not systems:
        show_msgbox("No systems found in manifest.")
        sys.exit(0)
    dialog_args = ['dialog','--stdout','--title','Select System','--menu',
                   "Choose a system to manage:", '25','80',str(min(len(systems),25))]
    for s in systems:
        count = len(s.get('games',[]))
        line = f"{s['name']} ({count} games)"
        dialog_args.extend([s['name'], line])
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    if result.returncode != 0:
        return None
    selected_tag = result.stdout.strip()
    for sy in systems:
        if sy['name'] == selected_tag:
            return sy
    return None

def apply_filters(games):
    filter_options = [
        ('1', 'Genre'),
        ('2', 'Rating'),
        ('3', 'Publisher'),
        ('4', 'Developer'),
        ('5', 'Number of Players'),
        ('6', 'Starting Letter'),
        ('7', 'Search by Name'),
        ('8', 'Done')
    ]
    filtered = games[:]
    while True:
        da = ['dialog','--stdout','--title','Filter Options','--menu',
              'Choose a filter criterion:','20','60','8']
        for o in filter_options:
            da.extend(o)
        with open('/dev/tty') as tty:
            rr = subprocess.run(da,capture_output=True,text=True,stdin=tty)
        if rr.returncode != 0:
            break
        choice = rr.stdout.strip()
        if choice == '' or choice=='8':
            break
        if choice=='1':
            val = get_input_from_osk("Genre Filter","Enter genre substring:")
            if val:
                filtered = [g for g in filtered if g.get('genre') and val.lower() in g['genre'].lower()]
        elif choice=='2':
            rating_val = get_input_from_osk("Rating Filter","Enter rating (1-5):")
            if rating_val and rating_val.isdigit():
                rv = int(rating_val)
                filtered = [g for g in filtered if g.get('rating') and g['rating'].replace('.','',1).isdigit() and int(round(float(g['rating'])))==rv]
        elif choice=='3':
            val = get_input_from_osk("Publisher Filter","Enter publisher substring:")
            if val:
                filtered = [g for g in filtered if g.get('publisher') and val.lower() in g['publisher'].lower()]
        elif choice=='4':
            val = get_input_from_osk("Developer Filter","Enter developer substring:")
            if val:
                filtered = [g for g in filtered if g.get('developer') and val.lower() in g['developer'].lower()]
        elif choice=='5':
            players_val = get_input_from_osk("Players Filter","Enter number of players (exact):")
            if players_val and players_val.isdigit():
                pv = int(players_val)
                filtered = [g for g in filtered if g.get('players') and g['players'].isdigit() and int(g['players'])==pv]
        elif choice=='6':
            letter = get_input_from_osk("Starting Letter","Enter a letter:")
            if letter:
                letter = letter[0]
                filtered = [g for g in filtered if g.get('name') and g['name'].lower().startswith(letter.lower())]
        elif choice=='7':
            val = get_input_from_osk("Search by Name","Enter name substring:")
            if val:
                filtered = [g for g in filtered if val.lower() in g['name'].lower()]
        else:
            pass
        if not ask_yes_no("Do you want to apply another filter?"):
            break
    return filtered

def select_games_to_download(games, installed_names):
    if not games:
        show_msgbox("No games found.")
        return []
    dialog_args = ['dialog','--stdout','--title','Select Games to Download','--checklist',
                   "Select the games to download:\n\nBack Button: Check Selection\nSelect Button: Save and Confirm Choices",
                   '25','100','20']
    for g in games:
        tag = g['url']
        status = 'off'
        display_name = g['name']
        if g['name'].strip().lower() in installed_names:
            display_name += " (Installed)"
        item = f"{display_name} ({g.get('size_human','N/A')})"
        dialog_args.extend([tag, item, status])
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    if result.returncode!=0:
        return []
    selected_urls = result.stdout.strip().split()
    selected_games = [gg for gg in games if gg['url'] in selected_urls]
    return selected_games

def check_space_for_download(selected_games):
    total_size = sum(g['size'] for g in selected_games)
    used,free,total = get_disk_usage(ROMS_DIR)
    if total_size > free:
        need = total_size - free
        show_msgbox(f"Not enough space.\nYou need an additional {format_size(need)} of free space.")
        return False
    else:
        show_msgbox(f"Estimated space to be used: {format_size(total_size)}. Sufficient space available.")
        return True

def final_confirmation(all_selected_games):
    total_size = sum(g['size'] for g in all_selected_games)
    message = "Final Download Summary:\n\n"
    for g in all_selected_games:
        message += f" - {g['name']} ({g['size_human']})\n"
    message += f"\nTotal Games: {len(all_selected_games)}\n"
    message += f"Total Space Required: {format_size(total_size)}\n\n"
    message += "Large packs may take a long time to download.\n"
    message += "Data usage may apply and is your responsibility.\n\n"
    message += "Do you want to proceed?"
    if not ask_yes_no(message):
        return False
    if not password_prompt("Enter password to confirm downloads:"):
        return False
    return True

def show_download_progress(filename, total_size, downloaded):
    """
    total_size in bytes, downloaded in bytes
    percentage
    """
    if total_size > 0:
        percent = int((downloaded / total_size) * 100)
    else:
        percent = 0
    msg = f"Downloading {filename}...\n{format_size(downloaded)} / {format_size(total_size)}"
    cmd = ['dialog', '--gauge', msg, '10', '50', str(percent)]
    subprocess.run(cmd, stdin=open('/dev/tty'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def download_game_pack(game, system_name):
    """
    If DRY_RUN is True, we simulate reading network chunks and updating gauge
    but do NOT write them to disk.
    """
    tmp_dir = '/tmp/game_downloads'
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)
    zip_filename = os.path.basename(game['url'])
    zip_path = os.path.join(tmp_dir, zip_filename)

    r = requests.get(game['url'], stream=True)
    r.raise_for_status()
    total_size = game['size']  # bytes
    downloaded = 0
    chunk_size = 8192

    if DRY_RUN:
        # We'll read the stream just to increment 'downloaded'
        # and update the gauge, but skip writing to disk.
        for chunk in r.iter_content(chunk_size=chunk_size):
            if chunk:
                downloaded += len(chunk)
                show_download_progress(zip_filename, total_size, downloaded)
        # Then just log that we "would have downloaded" it
        print(f"[DRY RUN] Would have saved file: {zip_path}")
    else:
        with open(zip_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    show_download_progress(zip_filename, total_size, downloaded)

def insert_game_snippet(system_name, snippet_path):
    if DRY_RUN:
        print(f"[DRY RUN] Would insert snippet into gamelist for {system_name}: {snippet_path}")
        return

    system_dir = os.path.join(ROMS_DIR, system_name)
    gamelist_path = os.path.join(system_dir, 'gamelist.xml')
    
    if not os.path.exists(gamelist_path):
        root = ET.Element('gameList')
        provider = ET.SubElement(root, 'provider')
        system_elem = ET.SubElement(provider, 'System')
        system_elem.text = system_name
        tree = ET.ElementTree(root)
        tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)
    
    try:
        snippet_tree = ET.parse(snippet_path)
        snippet_root = snippet_tree.getroot()
    except:
        show_msgbox("Error parsing snippet.xml")
        return

    try:
        tree = ET.parse(gamelist_path)
        root = tree.getroot()
    except:
        show_msgbox(f"Error parsing {gamelist_path}")
        return

    root.append(snippet_root)

    games = root.findall('game')
    def get_game_name(g):
        n = g.find('name')
        return n.text.strip().lower() if n is not None and n.text else ''

    games_sorted = sorted(games, key=get_game_name)
    for g in root.findall('game'):
        root.remove(g)
    for g in games_sorted:
        root.append(g)

    tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)

def extract_and_install(game, system_name):
    """
    If DRY_RUN is True, we skip actual extraction and copying,
    just log what would happen.
    """
    tmp_dir = '/tmp/game_downloads'
    zip_filename = os.path.basename(game['url'])
    zip_path = os.path.join(tmp_dir, zip_filename)

    system_dir = os.path.join(ROMS_DIR, system_name)
    images_dir = os.path.join(system_dir, IMAGES_SUBDIR)
    videos_dir = os.path.join(system_dir, VIDEOS_SUBDIR)

    if DRY_RUN:
        print(f"[DRY RUN] Would extract {zip_path}")
        print(f"[DRY RUN] Would copy ROMs to {system_dir}")
        print(f"[DRY RUN] Would copy images to {images_dir}")
        print(f"[DRY RUN] Would copy videos to {videos_dir}")
        snippet_path = os.path.join('/tmp/game_downloads','extract','snippet.xml')
        print(f"[DRY RUN] Would insert snippet if {snippet_path} existed.")
        return

    # Actually extract
    extract_path = os.path.join(tmp_dir, 'extract')
    if os.path.exists(extract_path):
        shutil.rmtree(extract_path)
    os.makedirs(extract_path)

    with zipfile.ZipFile(zip_path,'r') as zf:
        zf.extractall(extract_path)

    # Ensure system directories
    if not os.path.exists(system_dir):
        os.makedirs(system_dir)
    if not os.path.exists(images_dir):
        os.makedirs(images_dir)
    if not os.path.exists(videos_dir):
        os.makedirs(videos_dir)

    # Move ROMs
    roms_extract_dir = os.path.join(extract_path, 'roms')
    if os.path.exists(roms_extract_dir):
        for f in os.listdir(roms_extract_dir):
            shutil.copy(os.path.join(roms_extract_dir, f), system_dir)

    # Move Images
    images_extract_dir = os.path.join(extract_path, 'images')
    if os.path.exists(images_extract_dir):
        for f in os.listdir(images_extract_dir):
            shutil.copy(os.path.join(images_extract_dir, f), images_dir)

    # Move Videos
    videos_extract_dir = os.path.join(extract_path, 'videos')
    if os.path.exists(videos_extract_dir):
        for f in os.listdir(videos_extract_dir):
            shutil.copy(os.path.join(videos_extract_dir, f), videos_dir)

    # Insert snippet
    snippet_path = os.path.join(extract_path, 'snippet.xml')
    if os.path.exists(snippet_path):
        insert_game_snippet(system_name, snippet_path)

    # Clean up
    shutil.rmtree(extract_path)
    os.remove(zip_path)

def prompt_main_menu():
    opts = [
        ('1','View Current Storage Usage'),
        ('2','Select System to Download Games'),
        ('3','Exit')
    ]
    da = ['dialog','--stdout','--title','Main Menu','--menu','Choose an option:','20','60','3']
    for o in opts:
        da.extend(o)
    with open('/dev/tty') as tty:
        r=subprocess.run(da,capture_output=True,text=True,stdin=tty)
    if r.returncode!=0:
        return 'exit'
    return r.stdout.strip()

def main():
    parser = argparse.ArgumentParser(description="Download and Install Game Packs with Additional Features")
    parser.add_argument('--manifest-url', help='URL to manifest.json')
    parser.add_argument('--manifest', help='Path to local manifest.json')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose output')
    args = parser.parse_args()

    global VERBOSE
    VERBOSE = args.verbose

    disclaimer = (
        "WARNING: Our VintageVault tool allows you to download and add new games to your arcade.\n"
        "These changes add ROMs, images, videos and update gamelist.xml.\n\n"
        "You must enter the password 'iagree' to proceed.\n\n"
        "By entering the password, you understand to our Terms and Conditions.\n"
    )
    show_msgbox(disclaimer, height=20, width=70, title="Disclaimer")
    if not password_prompt("Enter password to proceed:"):
        sys.exit(0)

    if args.manifest_url:
        manifest_data = load_manifest(manifest_url=args.manifest_url)
    elif args.manifest:
        manifest_data = load_manifest(manifest_path=args.manifest)
    else:
        show_msgbox("No manifest specified. Use --manifest or --manifest-url.")
        sys.exit(1)

    all_selected_games = []

    while True:
        choice = prompt_main_menu()
        if choice=='3' or choice=='exit':
            if all_selected_games:
                pass
            sys.exit(0)
        elif choice=='1':
            show_storage_usage()
        elif choice=='2':
            systems = list_systems(manifest_data)
            selected_system = select_system(systems)
            if selected_system is None:
                continue
            all_games = selected_system.get('games',[])
            if not all_games:
                show_msgbox("No games in this system.")
                continue
            if ask_yes_no("Do you want to apply filters?"):
                filtered_games = apply_filters(all_games)
            else:
                filtered_games = all_games

            installed_names = parse_gamelist_for_installed(selected_system['name'])
            selected_for_system = select_games_to_download(filtered_games, installed_names)
            if not selected_for_system:
                show_msgbox("No games selected.")
                if not ask_yes_no("Do you want to select another system?"):
                    continue
                else:
                    continue
            all_selected_games.extend([(g, selected_system['name']) for g in selected_for_system])

            if not ask_yes_no("Do you want to select games from another system?"):
                break
            else:
                continue
        else:
            pass

    if not all_selected_games:
        show_msgbox("No games selected from any system.")
        sys.exit(0)

    total_size = sum(g[0]['size'] for g in all_selected_games)
    summary_msg = "Final Download Summary:\n\n"
    for g, sysn in all_selected_games:
        summary_msg += f" - {g['name']} ({g['size_human']}) [{sysn}]\n"
    summary_msg += f"\nTotal Games: {len(all_selected_games)}\n"
    summary_msg += f"Total Space Required: {format_size(total_size)}\n\n"
    summary_msg += "Large packs may take a long time.\nData usage may apply.\n\n"
    summary_msg += "Do you want to proceed?"

    if not ask_yes_no(summary_msg):
        show_msgbox("Operation cancelled. No changes made.")
        sys.exit(0)

    if not password_prompt("Enter password to confirm downloads:"):
        show_msgbox("Incorrect password. No changes made.")
        sys.exit(0)

    # DRY_RUN or real downloads
    for g, sysn in all_selected_games:
        download_game_pack(g, sysn)
        # if DRY_RUN, extract_and_install will skip actual copying
        extract_and_install(g, sysn)

    show_msgbox(
        "Reboot is required for changes to be made.\n\n"
        "Press OK to reboot when ready.",
        height=10, width=50, title="Reboot Required"
    )

    if DRY_RUN:
        show_msgbox("[DRY RUN] Would reboot now, but skipping because DRY_RUN is True.")
    else:
        subprocess.run(['sudo','reboot'])

if __name__ == "__main__":
    main()
