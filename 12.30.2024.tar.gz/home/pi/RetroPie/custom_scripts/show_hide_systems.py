#!/usr/bin/env python3

import os
import subprocess
import sys
import shutil
import datetime
import xml.etree.ElementTree as ET
import logging
from logging.handlers import RotatingFileHandler
import argparse

# Paths
ES_SYSTEMS_CFG_PATH = '/etc/emulationstation/es_systems.cfg'
BACKUP_PATH = ES_SYSTEMS_CFG_PATH + '.backup'
LOG_FILE = '/home/pi/RetroPie/custom_scripts/logs/show_hide_systems.log'  # Path to the log file

# Path to your master system list
MASTER_LIST_FILE = '/home/pi/RetroPie/custom_scripts/lists/master_lists/system_limit_list.txt'

# Logging Configuration
MAX_LOG_SIZE = 5 * 1024 * 1024  # 5 MB
BACKUP_COUNT = 3  # Number of backup log files to keep

# Set up logging with rotation
logger = logging.getLogger('CustomScriptLogger')
logger.setLevel(logging.INFO)

handler = RotatingFileHandler(LOG_FILE, maxBytes=MAX_LOG_SIZE, backupCount=BACKUP_COUNT)
formatter = logging.Formatter('[%(asctime)s] %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Global verbosity flag
VERBOSE = False  # Set to True for debugging, False to hide console logs

# Function to get current timestamp
def timestamp():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Function to log messages
def log_message(message):
    logger.info(message)
    if VERBOSE:
        print(f"[{timestamp()}] {message}")

# Function to read master list file
def read_master_list(filepath):
    """
    Reads the master list file (one system fullname per line).
    Any line starting with '#' (or empty) is skipped.
    Returns a set of system fullnames to allow quick membership checks.
    """
    master_set = set()
    
    if not os.path.exists(filepath):
        log_message(f"[WARNING] Master list file not found at: {filepath}")
        return master_set  # Return empty set if the file doesn't exist

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # Skip blank lines or lines starting with '#'
                if not line or line.startswith('#'):
                    continue
                master_set.add(line)
    except Exception as e:
        log_message(f"[ERROR] Could not read master list file: {e}")

    log_message(f"Master list loaded with {len(master_set)} entries.")
    return master_set

# Function to reboot the Raspberry Pi
def reboot_pi():
    log_message("Attempting to reboot the Raspberry Pi...")
    try:
        # Notify user via dialog before rebooting
        subprocess.run(['dialog', '--msgbox', 'The system will now reboot. Please wait.', '10', '50'])
        log_message("Reboot confirmation shown to the user.")
        
        # Execute the reboot command
        subprocess.run(['sudo', 'reboot'])
        log_message("Reboot command executed.")
    except Exception as e:
        log_message(f"Error rebooting the Raspberry Pi: {e}")
        subprocess.run(['dialog', '--msgbox', f'Error rebooting the system: {e}', '10', '50'])

# Function to backup the original configuration file
def backup_config():
    try:
        shutil.copyfile(ES_SYSTEMS_CFG_PATH, BACKUP_PATH)
        log_message("Backup of es_systems.cfg created.")
    except Exception as e:
        log_message(f"Error creating backup of es_systems.cfg: {e}")
        subprocess.run(['dialog', '--msgbox', f'Error creating backup of es_systems.cfg: {e}', '10', '50'])
        sys.exit(1)

# Function to restore from backup
def restore_backup():
    try:
        shutil.copyfile(BACKUP_PATH, ES_SYSTEMS_CFG_PATH)
        log_message("es_systems.cfg has been restored from the backup.")
        subprocess.run(['dialog', '--msgbox', 'Configuration has been restored from the backup.', '10', '50'])
    except Exception as e:
        log_message(f"Error restoring backup: {e}")
        subprocess.run(['dialog', '--msgbox', f'Error restoring backup: {e}', '10', '50'])
        sys.exit(1)

# Function to parse the XML and extract systems
def parse_systems(file_path):
    log_message(f"Reading and parsing XML file: {file_path}")
    
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
    except Exception as e:
        log_message(f"Error parsing XML file {file_path}: {e}")
        subprocess.run(['dialog', '--msgbox', f'Error parsing configuration file: {e}', '10', '50'])
        sys.exit(1)

    systems = root.findall('system')
    log_message(f"Found {len(systems)} systems in the configuration file.")

    parsed_systems = []
    for idx, system in enumerate(systems, start=1):
        path_elem = system.find('path')
        if path_elem is not None:
            path = path_elem.text.strip()
            commented = path.startswith('/hidden')
            parsed_systems.append((system, commented))
            log_message(f"System {idx}: Path = '{path}', Commented = {commented}")
        else:
            log_message(f"Warning: <path> tag not found in system {idx}. System skipped.")

    return parsed_systems, tree, root

# Function to prepare checklist options
def prepare_checklist(systems, master_list):
    checklist_options = []

    for system, commented in systems:
        name_elem = system.find('name')
        fullname_elem = system.find('fullname')

        if name_elem is not None and fullname_elem is not None:
            name = name_elem.text.strip()
            fullname = fullname_elem.text.strip()

            log_message(f"Processing system: Name = '{name}', Fullname = '{fullname}', Commented = {commented}")

            # ----------------------------------------------------------------
            # *** FILTER: only show if fullname is in the master_list ***
            # ----------------------------------------------------------------
            if fullname not in master_list:
                log_message(f"Skipping '{fullname}' because it's not in the master list.")
                continue
            # ----------------------------------------------------------------

            # Also skip 'retropie' system entirely
            if name.lower() == "retropie":
                log_message(f"Excluding system '{name}' from the checklist.")
                continue

            # Determine current status
            status_text = "Currently Hidden" if commented else "Currently Visible"

            # 'on' if the system is currently visible
            status = 'on' if not commented else 'off'

            # Display text
            display_text = f"{fullname} - {status_text}"

            # Check for special characters that might interfere with dialog
            if any(c in display_text for c in ['"', "'", '`', '\\']):
                log_message(f"Warning: System '{name}' fullname contains special characters: '{fullname}'")

            # Append to checklist_options as (tag, item, status)
            checklist_options.append((name, display_text, status))
        else:
            log_message("Warning: <name> or <fullname> tag not found in a <system> block.")

    log_message(f"Prepared {len(checklist_options)} checklist options.")
    log_message(f"Checklist options: {checklist_options}")

    return checklist_options

# Function to display the checklist and get user choices
def get_user_choices(checklist_options):
    if not checklist_options:
        log_message("No systems available for customization.")
        subprocess.run(['dialog', '--msgbox', 'No systems available for customization.', '10', '50'])
        sys.exit(0)

    # Prepare checklist options for dialog
    dialog_args = [
        'dialog', '--stdout', '--title', 'Customize Systems', '--checklist',
        'Show or hide from the system selection menu\n\nUse your controls as follows:\n\nBack Button: Check Selection\nSelect Button: Save and confirm choices',
        '30', '100', '25'  # Height, Width, List-Height
    ]

    # Add the checklist options as dialog arguments
    for option in checklist_options:
        tag, item, status = option
        dialog_args.extend([tag, item, status])

    # Log the full dialog arguments
    log_message(f"Dialog arguments ({len(dialog_args)} total): {dialog_args}")

    # Show checklist for user to select systems
    result = subprocess.run(dialog_args, capture_output=True, text=True)

    if result.returncode != 0:
        log_message("Dialog was cancelled or encountered an error.")
        log_message(f"Dialog stdout: {result.stdout}")
        log_message(f"Dialog stderr: {result.stderr}")  # Log stderr for detailed error
        subprocess.run(['dialog', '--msgbox', 'No changes made. Returning to menu.', '10', '50'])
        sys.exit(1)

    choices = result.stdout.strip().split()

    # Log the raw output from the dialog
    log_message(f"Dialog stdout: {result.stdout}")
    log_message(f"User choices: {choices}")

    return choices

# Function to display a summary of changes
def display_summary(systems, choices):
    summary_lines = []
    for system, commented in systems:
        name_elem = system.find('name')
        fullname_elem = system.find('fullname')

        if name_elem is None or fullname_elem is None:
            continue

        name = name_elem.text.strip()
        fullname = fullname_elem.text.strip()

        if name.lower() == "retropie":
            continue  # Skip retropie

        if name in choices:
            action = "Unhide" if commented else "No Change"
        else:
            action = "Hide" if not commented else "No Change"

        if action != "No Change":
            summary_lines.append(f"{action} - {fullname}")

    if summary_lines:
        summary = "The following changes will be applied:\n\n" + "\n".join(summary_lines)
        subprocess.run(['dialog', '--msgbox', summary, '15', '60'])
        log_message("Summary of changes displayed to the user.")
    else:
        subprocess.run(['dialog', '--msgbox', 'Attention: No changes have been detected.', '10', '50'])
        log_message("No changes to display in summary.")

# Function to modify the XML based on user choices
def modify_systems(systems, choices, root, dry_run=False):
    changes_made = False
    for system, commented in systems:
        name_elem = system.find('name')
        path_elem = system.find('path')

        if name_elem is None or path_elem is None:
            log_message("Warning: <name> or <path> tag missing. Skipping system.")
            continue

        name = name_elem.text.strip()

        if name.lower() == "retropie":
            log_message(f"Skipping 'retropie' system: {name}")
            continue  # Exclude 'retropie' from modifications

        original_path = path_elem.text.strip()

        if name in choices:
            if commented:
                # Uncomment the system (remove /hidden from the path)
                new_path = original_path.replace('/hidden', '', 1)
                action = f"Uncomment - {name}: {original_path} -> {new_path}"
                if dry_run:
                    log_message(f"[Dry Run] {action}")
                else:
                    path_elem.text = new_path
                    log_message(f"Uncommenting system: {name}")
                changes_made = True
            else:
                # Already visible, no change needed
                log_message(f"No change for system (already visible): {name}")
        else:
            if not commented:
                # Comment out the system (add /hidden to the path)
                new_path = f"/hidden{original_path}"
                action = f"Comment - {name}: {original_path} -> {new_path}"
                if dry_run:
                    log_message(f"[Dry Run] {action}")
                else:
                    path_elem.text = new_path
                    log_message(f"Commenting out system: {name}")
                changes_made = True
            else:
                # Already hidden, no change needed
                log_message(f"No change for system (already hidden): {name}")

    if not changes_made:
        log_message("No changes were made to the configuration.")
        return False  # No changes made
    else:
        return True  # Changes were made

# Function to write the modified XML back to the file
def write_config(tree):
    try:
        tree.write(ES_SYSTEMS_CFG_PATH, encoding='utf-8', xml_declaration=True)
        log_message("es_systems.cfg has been updated.")
    except Exception as e:
        log_message(f"Error writing to es_systems.cfg: {e}")
        subprocess.run(['dialog', '--msgbox', f'Error writing to es_systems.cfg: {e}', '10', '50'])
        sys.exit(1)

# Function to parse command-line arguments
def parse_arguments():
    parser = argparse.ArgumentParser(description='Customize EmulationStation Systems')
    parser.add_argument('--restore', action='store_true', help='Restore the original es_systems.cfg from backup')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--dry-run', action='store_true', help='Show changes without applying them')
    return parser.parse_args()

# Function to check if the script is run with sudo
def check_permissions():
    if os.geteuid() != 0:
        subprocess.run(['dialog', '--msgbox', 'This script must be run with sudo. Please run again using sudo.', '10', '50'])
        sys.exit(1)

# Function to prompt user to exit or return to menu
def prompt_exit_or_continue():
    exit_choice = subprocess.run(
        ['dialog', '--stdout', '--title', 'No Changes Detected',
         '--yesno', 'Do you want to exit and return to the main menu?', '10', '60'],
        capture_output=True, text=True
    )
    if exit_choice.returncode == 0:
        # User chose Yes (exit)
        log_message("User chose to exit without making changes.")
        subprocess.run(['dialog', '--msgbox', 'Exiting without making changes.', '10', '50'])
        sys.exit(0)
    else:
        # User chose No (continue)
        log_message("User chose to continue making changes.")
        return

def main():
    # Parse command-line arguments
    args = parse_arguments()

    # Set verbosity
    global VERBOSE
    VERBOSE = args.verbose

    if args.restore:
        restore_backup()
        sys.exit(0)

    # Ensure the script is run with sudo
    check_permissions()

    # Backup the original configuration file
    backup_config()

    # 1. Read the master list once outside the loop
    master_list = read_master_list(MASTER_LIST_FILE)

    while True:
        # Read the XML file and parse it with ElementTree
        log_message("Parsing the es_systems.cfg file...")
        systems, tree, root = parse_systems(ES_SYSTEMS_CFG_PATH)
        log_message(f"Parsed {len(systems)} systems.")

        # Prepare checklist options based on the master list
        checklist_options = prepare_checklist(systems, master_list)

        # Show checklist and get user choices
        choices = get_user_choices(checklist_options)

        # Proceed only if the user selected systems
        if choices:
            log_message("User made selections. Proceeding with modification.")
            display_summary(systems, choices)

            # Modify systems and check if changes were made
            changes_made = modify_systems(systems, choices, root, dry_run=args.dry_run)

            if changes_made:
                if args.dry_run:
                    subprocess.run(['dialog', '--msgbox', 'Dry run complete. No changes were applied.', '10', '50'])
                    log_message("Dry run mode: Changes were simulated but not applied.")
                else:
                    # Write the changes to the configuration file
                    write_config(tree)

                    # Notify user of success
                    subprocess.run(['dialog', '--msgbox', 'Your choices have been made and the configuration has been successfully updated!', '10', '50'])
                    log_message("Customization complete. Success message shown to user.")

                    # Prompt to reboot the Raspberry Pi
                    subprocess.run(['dialog', '--msgbox', 'To apply changes, the system will reboot. Press OK to proceed.', '10', '50'])
                    reboot_pi()
                    sys.exit(0)
            else:
                # No changes were made based on selections
                log_message("No changes were made based on user selections.")
                prompt_exit_or_continue()
                # If the user chooses to continue, the loop will iterate again

        else:
            # No systems were selected
            log_message("No systems were selected. No changes were made.")
            subprocess.run(['dialog', '--msgbox', 'No systems were selected. No changes were made.', '10', '50'])
            # Prompt to exit or continue
            prompt_exit_or_continue()
            # If the user chooses to continue, the loop will iterate again

if __name__ == "__main__":
    main()
