#!/usr/bin/env python3
import os
import sys
import shutil
import datetime
import xml.etree.ElementTree as ET
import subprocess
import logging
from logging.handlers import RotatingFileHandler
import argparse
from pathlib import Path
import fnmatch
import traceback
import math

try:
    import psutil
except ImportError:
    # Attempt to install psutil if not present
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "psutil"])
        import psutil
    except Exception:
        print("Could not install or import psutil. Please ensure it is installed.")
        sys.exit(1)

# =========================================================
#                    CONFIGURATION
# =========================================================

ROMS_DIR = '/home/pi/RetroPie/roms'
PASSWORD = "iagree"
LOG_DIR = '/home/pi/RetroPie/custom_scripts/logs/deletion_logs/'  # Ensure this exists
os.makedirs(LOG_DIR, exist_ok=True)
VERBOSE = False

ROM_EXTENSIONS = {'.zip', '.chd', '.iso', '.cue', '.cdi', '.tic', '.img', '.sub', '.ccd'}
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg'}
VIDEO_EXTENSIONS = {'.mp4', '.avi', '.mkv'}

SESSION_LOG = None

logger = logging.getLogger('ManageStorageLogger')
logger.setLevel(logging.DEBUG)

# ---------------- NEW DRY RUN FLAG ---------------
DRY_RUN = True   # <-- Set this to False to actually delete/modify files and reboot.

# =========================================================
#                   ON-SCREEN KEYBOARD (Embedded)
# =========================================================
import urwid

PALETTE = [
    ('input', 'dark gray', 'light gray'),
    ('input text', 'black', 'light gray'),
    ('prompt', 'dark red', 'dark cyan'),
    ('body', 'black', 'light gray'),
    ('bg', 'white', 'dark blue'),
    ('focus key', 'white', 'dark blue'),
    ('header', 'light cyan', 'dark blue'),
    ('error', 'dark red', 'light gray'),
    ('button', 'black', 'light gray'),
    ('selected', 'white', 'dark blue'),
    ('label', 'dark gray', 'light gray'),
    ('label selected', 'yellow', 'dark blue'),
]

ASCII_BLOCK = '█'

class CenteredButton(urwid.WidgetWrap):
    signals = ["click"]
    def __init__(self, label, on_press=None, user_data=None, delimiters=True):
        self._label = urwid.Text(label, align='center')
        if delimiters:
            cols = urwid.Columns([
                ('fixed',1, urwid.Text("<")),
                self._label,
                ('fixed',1, urwid.Text(">"))
            ], dividechars=1)
        else:
            cols = self._label
        super().__init__(cols)
        if on_press:
            urwid.connect_signal(self, 'click', on_press, user_data)

    def selectable(self):
        return True

    def keypress(self, size, key):
        if self._command_map[key] == urwid.ACTIVATE and key != ' ':
            self._emit('click')
        else:
            return key

    def mouse_event(self, size, event, button, x, y, focus):
        return False

class KeyButton(CenteredButton):
    def __init__(self, label, primary=None, secondary=None, on_press=None, user_data=None):
        super().__init__(label, on_press, user_data, delimiters=False)
        self.primary_val = primary if primary is not None else label
        self.secondary_val = secondary if secondary is not None else (label.upper() if len(label)==1 else None)

    def shift(self, shifted):
        if shifted and self.secondary_val:
            self._label.set_text(self.secondary_val)
        else:
            self._label.set_text(self.primary_val)

    def get_value(self, shifted):
        return self.secondary_val if shifted and self.secondary_val else self.primary_val

class ViewExit(Exception):
    pass

class OSK:
    def __init__(self, title="On-Screen Keyboard", prompt_title="Enter Text"):
        self._prompt_title = prompt_title
        self._shift = False
        self.keys = []
        self.frame = self.setup_frame(title, prompt_title)
        self.pop_up = self.setup_popup("Error")
        self.view = urwid.Overlay(self.pop_up, self.frame, 'center',None,'middle',None)

    def setup_frame(self, title, prompt):
        header = urwid.LineBox(urwid.Text(title, align='center'),
                               tline=None, rline=' ', lline=' ',
                               trcorner=' ', tlcorner=' ', blcorner='', brcorner='')
        header = urwid.AttrWrap(header, 'header')

        self.input = urwid.Text([('input text',''),('prompt',ASCII_BLOCK)])
        input_box = urwid.LineBox(self.input)
        input_box = urwid.AttrWrap(input_box,'input text')

        # Helper to create a key
        def make_key(primary, secondary=None, callback=None):
            if callback is None:
                callback = self.def_key_press
            btn = KeyButton(primary, primary=primary, secondary=secondary, on_press=callback)
            self.keys.append(btn)
            return urwid.AttrWrap(btn, None, 'focus key')
        self.make_key = make_key

        # Helper to create a row of keys
        def row_of_keys(*keybuttons):
            return urwid.GridFlow(keybuttons, 8, 1, 5, 'center')

        # Top row
        top_row = row_of_keys(
            make_key('`','~'),make_key('1','!'),make_key('2','@'),make_key('3','#'),
            make_key('4','$'),make_key('5','%'),make_key('6','^'),make_key('7','&'),
            make_key('8','*'),make_key('9','('),make_key('0',')'),
            make_key('-','_'),make_key('=','+')
        )

        second_row = row_of_keys(
            make_key('q'), make_key('w'), make_key('e'), make_key('r'), make_key('t'),
            make_key('y'), make_key('u'), make_key('i'), make_key('o'), make_key('p'),
            make_key('[','{'), make_key(']','}'), make_key('\\','|')
        )

        third_row = row_of_keys(
            make_key('a'), make_key('s'), make_key('d'), make_key('f'), make_key('g'),
            make_key('h'), make_key('j'), make_key('k'), make_key('l'),
            make_key(';',':'),make_key("'",'"')
        )

        fourth_row = row_of_keys(
            make_key('z'), make_key('x'), make_key('c'), make_key('v'), make_key('b'),
            make_key('n'), make_key('m'), make_key(',', '<'), make_key('.','>'), make_key('/','?')
        )

        shift_btn = make_key('↑ Shift','↑ SHIFT', callback=self.shift_key_press)
        space_btn = make_key('Space',' ', callback=self.def_key_press)
        bksp_btn = make_key('Delete ←', callback=self.bksp_key_press)
        fifth_row = row_of_keys(shift_btn, space_btn, bksp_btn)

        ok_btn = self.setup_button("OK", self.button_press, exitcode=0)
        cancel_btn = self.setup_button("Cancel", self.button_press, exitcode=1)

        main_pile = urwid.Pile([
            urwid.Text(prompt,align='center'),
            urwid.Padding(input_box,'center',80),
            urwid.Divider(),
            top_row, urwid.Divider(),
            second_row, urwid.Divider(),
            third_row, urwid.Divider(),
            fourth_row, urwid.Divider(),
            fifth_row, urwid.Divider(),
            urwid.GridFlow([ok_btn, cancel_btn], 10,2,0,'center'),
            urwid.Divider(),
        ])

        main_pile = urwid.AttrWrap(main_pile, 'body')
        main_pile = urwid.Padding(main_pile,'center',120)
        main_pile = urwid.Filler(main_pile,'middle')

        frame = urwid.Frame(main_pile, header=header, focus_part='body')
        return frame

    def setup_button(self,label,cb,exitcode):
        b = CenteredButton(('label',label),cb,delimiters=True)
        b.exitcode = exitcode
        return urwid.AttrMap(b,{None:'button'},{None:'selected','label':'label selected'})

    def setup_popup(self,title):
        header = urwid.AttrWrap(urwid.Text(title, align='center'),'header')
        self._error = urwid.Text("",align='center')
        error_text = urwid.AttrWrap(self._error,'error')
        dismiss_btn = self.setup_button("Dismiss",self.close_popup,exitcode=None)
        box = urwid.LineBox(
            urwid.Pile([
                urwid.Divider(),
                error_text,
                urwid.Divider(),
                urwid.LineBox(
                    urwid.GridFlow([dismiss_btn],12,2,0,'center'),
                    bline=None,lline=None,rline=None,tlcorner='─',trcorner='─'
                )
            ])
        )
        box = urwid.AttrWrap(box,'body')
        box = urwid.Filler(box,'middle')
        return urwid.Frame(
            urwid.Padding(box,'center',50),
            header=header,focus_part='body'
        )

    def close_popup(self, widget=None):
        self.loop.widget = self.frame

    def open_popup(self):
        self.loop.widget = self.pop_up

    def set_error_text(self,msg):
        self._error.set_text(msg)

    def def_key_press(self,btn):
        val = btn.get_value(self._shift)
        if val:
            txt = self.input.get_text()[0].rstrip(ASCII_BLOCK)
            self.input.set_text([('input text',txt+val),('prompt',ASCII_BLOCK)])
        if self._shift:
            self.shift_key_press()

    def bksp_key_press(self,btn=None):
        txt = self.input.get_text()[0].rstrip(ASCII_BLOCK)
        if txt:
            txt = txt[:-1]
        self.input.set_text([('input text',txt),('prompt',ASCII_BLOCK)])

    def shift_key_press(self,btn=None):
        self._shift = not self._shift
        for k in self.keys:
            k.original_widget.shift(self._shift)

    def button_press(self,btn):
        if btn.exitcode == 0:
            # OK pressed
            raise ViewExit(0)
        else:
            # Cancel pressed
            raise ViewExit(1)

    def unhandled_key(self,key):
        if len(key)==1 and ord(key) in range(32,127):
            txt = self.input.get_text()[0].rstrip(ASCII_BLOCK)
            self.input.set_text([('input text',txt+key),('prompt',ASCII_BLOCK)])
            return
        if key=='backspace':
            self.bksp_key_press()
        if key=='esc':
            # Treat Esc as cancel
            raise ViewExit(1)
        return key

    def main(self):
        self.loop = urwid.MainLoop(self.frame,PALETTE,unhandled_input=self.unhandled_key)
        try:
            self.loop.run()
            return 1,""
        except ViewExit as e:
            txt = self.input.get_text()[0].rstrip(ASCII_BLOCK)
            return e.args[0], txt

def get_input_from_osk(title, prompt):
    osk = OSK(title, prompt)
    code, text = osk.main()
    if code != 0:
        return ""
    return text

# =========================================================
#                    HELPER FUNCTIONS
# =========================================================
def log_action(message):
    if SESSION_LOG:
        SESSION_LOG.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
        SESSION_LOG.flush()

def format_size(bytes_size):
    for unit in ['B','KB','MB','GB','TB']:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} PB"

def get_disk_usage(path):
    usage = psutil.disk_usage(path)
    return usage.used, usage.free, usage.total

def show_msgbox(message, height=10, width=80, title="Message"):
    subprocess.run(['dialog','--msgbox',message,str(height),str(width)],stdin=open('/dev/tty'))

def ask_yes_no(question, title="Confirmation", height=10, width=80):
    dialog_args = [
        'dialog','--stdout','--title',title,'--yesno',question,str(height),str(width)
    ]
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    return (result.returncode == 0)

# Added cancel handling logic in password_prompt
def password_prompt(prompt, initial=False, final=False):
    attempts = 3
    while attempts > 0:
        pwd = get_input_from_osk("Password Required", prompt)
        if pwd == "":
            # User cancelled
            if initial:
                # Ask if they want to exit
                if ask_yes_no("Are you sure you want to exit without entering the password?\nNo changes will be made.", "Exit?"):
                    # Instead of sys.exit(0) here:
                    return None  # Return None to indicate exit requested.
                # If No, just continue the loop and re-ask
                continue
            elif final:
                # Ask if they want to cancel final confirmation
                if ask_yes_no("Are you sure you want to cancel and return to the previous menu?\nNo deletions will be applied.", "Cancel Confirmation?"):
                    return False
                # If No, re-ask password without decrementing attempts
                continue
            else:
                # Not initial or final, just return False (no decrement)
                return False
        elif pwd == PASSWORD:
            return True
        else:
            # Incorrect password typed
            attempts -= 1
            if attempts > 0:
                show_msgbox(f"Incorrect password. {attempts} attempt(s) remaining.")

    # If attempts are exhausted
    show_msgbox("Incorrect password entered too many times. No changes made.")
    return False


def get_systems():
    systems = []
    for entry in os.listdir(ROMS_DIR):
        system_dir = os.path.join(ROMS_DIR, entry)
        if os.path.isdir(system_dir):
            gamelist_path = os.path.join(system_dir,'gamelist.xml')
            if os.path.exists(gamelist_path):
                if has_roms(system_dir):
                    system_name = get_system_name(gamelist_path)
                    total_games, total_size = calculate_system_size_and_count(system_dir,gamelist_path)
                    systems.append({
                        'dir_name': entry,
                        'gamelist_path': gamelist_path,
                        'system_name': system_name,
                        'total_games': total_games,
                        'total_size': total_size
                    })
    systems.sort(key=lambda x: x['system_name'].lower())
    return systems

def has_roms(directory):
    for root, dirs, files in os.walk(directory):
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in ROM_EXTENSIONS:
                return True
    return False

def get_system_name(gamelist_path):
    try:
        tree = ET.parse(gamelist_path)
        root = tree.getroot()
        system_tag = root.find('provider/System')
        if system_tag is not None and system_tag.text:
            return system_tag.text.strip()
    except:
        pass
    return Path(gamelist_path).parent.name

def calculate_system_size_and_count(system_dir,gamelist_path):
    tree = ET.parse(gamelist_path)
    root = tree.getroot()
    games = root.findall('game')
    total_size = 0
    count = 0
    for g in games:
        rom_path = g.find('path')
        if rom_path is None or not rom_path.text:
            continue
        rp = rom_path.text.strip()
        if rp.startswith('file://'):
            rp = rp[7:]
        full_rom_path = os.path.join(system_dir, rp)
        sz = 0
        if os.path.exists(full_rom_path):
            sz += os.path.getsize(full_rom_path)
        img = g.find('image')
        if img is not None and img.text:
            imgp = img.text.strip()
            if imgp.startswith('file://'):
                imgp = imgp[7:]
            imgf = os.path.join(system_dir,imgp)
            if os.path.exists(imgf):
                sz += os.path.getsize(imgf)
        vid = g.find('video')
        if vid is not None and vid.text:
            vidp = vid.text.strip()
            if vidp.startswith('file://'):
                vidp = vidp[7:]
            vidf = os.path.join(system_dir,vidp)
            if os.path.exists(vidf):
                sz += os.path.getsize(vidf)
        total_size += sz
        count+=1
    return count,total_size

def select_system(systems):
    if not systems:
        show_msgbox("No systems with games found.")
        return None
    dialog_args = [
        'dialog','--stdout','--title','Select System','--menu',
        "Choose a system to manage:",
        '25','80',str(min(len(systems),25))
    ]
    for sysinfo in systems:
        sysline = f"{sysinfo['system_name']} ({sysinfo['total_games']} games, {format_size(sysinfo['total_size'])})"
        tag = sysinfo['dir_name']
        dialog_args.extend([tag, sysline])
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    if result.returncode != 0:
        return None
    selected_tag = result.stdout.strip()
    if not selected_tag:
        return None
    for s in systems:
        if s['dir_name'] == selected_tag:
            return s
    return None

def parse_gamelist(gamelist_path):
    tree = ET.parse(gamelist_path)
    root = tree.getroot()
    system_name = get_system_name(gamelist_path)
    games = []
    for game in root.findall('game'):
        ginfo = {}
        def getval(tag):
            t = game.find(tag)
            return t.text.strip() if t is not None and t.text else None
        ginfo['element'] = game
        ginfo['name'] = getval('name')
        ginfo['rom_path'] = getval('path')
        if ginfo['rom_path'] and ginfo['rom_path'].startswith('file://'):
            ginfo['rom_path'] = ginfo['rom_path'][7:]
        ginfo['genre'] = getval('genre')
        ginfo['rating'] = getval('rating')
        ginfo['publisher'] = getval('publisher')
        ginfo['developer'] = getval('developer')
        ginfo['players'] = getval('players')
        ginfo['image_path'] = getval('image')
        if ginfo['image_path'] and ginfo['image_path'].startswith('file://'):
            ginfo['image_path'] = ginfo['image_path'][7:]
        ginfo['video_path'] = getval('video')
        if ginfo['video_path'] and ginfo['video_path'].startswith('file://'):
            ginfo['video_path'] = ginfo['video_path'][7:]
        games.append(ginfo)
    return system_name,games,tree,root

def apply_filters(games, filters):
    filtered = games
    for ftype,fval in filters.items():
        if ftype == 'genre':
            filtered = [g for g in filtered if g['genre'] and fval.lower() in g['genre'].lower()]
        elif ftype == 'publisher':
            filtered = [g for g in filtered if g['publisher'] and fval.lower() in g['publisher'].lower()]
        elif ftype == 'developer':
            filtered = [g for g in filtered if g['developer'] and fval.lower() in g['developer'].lower()]
        elif ftype == 'name':
            filtered = [g for g in filtered if g['name'] and fval.lower() in g['name'].lower()]
        elif ftype == 'players':
            filtered = [g for g in filtered if g['players'] and g['players'].isdigit() and int(g['players']) == int(fval)]
        elif ftype == 'letter':
            filtered = [g for g in filtered if g['name'] and g['name'].lower().startswith(fval.lower())]
        elif ftype == 'rating':
            user_rating = int(fval)
            newlist=[]
            for gg in filtered:
                if gg['rating']:
                    try:
                        r = float(gg['rating'])
                        if round(r)==user_rating:
                            newlist.append(gg)
                    except:
                        pass
            filtered=newlist
    return filtered

def get_game_size(system_dir,game):
    size = 0
    if game['rom_path']:
        rp = os.path.join(system_dir,game['rom_path'])
        if os.path.exists(rp):
            size+=os.path.getsize(rp)
    if game['image_path']:
        ip = os.path.join(system_dir,game['image_path'])
        if os.path.exists(ip):
            size+=os.path.getsize(ip)
    if game['video_path']:
        vp = os.path.join(system_dir,game['video_path'])
        if os.path.exists(vp):
            size+=os.path.getsize(vp)
    return size

def select_filter(games):
    filters={}
    while True:
        options = [
            ('1','Genre'),
            ('2','Rating'),
            ('3','Publisher'),
            ('4','Developer'),
            ('5','Number of Players'),
            ('6','Starting Letter'),
            ('7','Search by Name'),
            ('8','Done')
        ]
        da = ['dialog','--stdout','--title','Filter Options','--menu','Select a filter:','20','60','8']
        for o in options:
            da.extend(o)
        with open('/dev/tty') as tty:
            result = subprocess.run(da,capture_output=True,text=True,stdin=tty)
        if result.returncode!=0:
            break
        choice = result.stdout.strip()
        if not choice or choice=='8':
            break
        if choice=='1':
            val = get_input_from_osk("Genre Filter","Enter genre substring:")
            if val:
                filters['genre']=val
        elif choice=='2':
            rating_options = [('1','1'),('2','2'),('3','3'),('4','4'),('5','5')]
            ra_args = ['dialog','--stdout','--title','Select Rating','--menu','Choose a rating:','15','40','5']
            for ro in rating_options:
                ra_args.extend(ro)
            with open('/dev/tty') as tty:
                rr = subprocess.run(ra_args,capture_output=True,text=True,stdin=tty)
            if rr.returncode==0 and rr.stdout.strip():
                filters['rating']=rr.stdout.strip()
        elif choice=='3':
            val = get_input_from_osk("Publisher Filter","Enter publisher substring:")
            if val:
                filters['publisher']=val
        elif choice=='4':
            val = get_input_from_osk("Developer Filter","Enter developer substring:")
            if val:
                filters['developer']=val
        elif choice=='5':
            players_options = [('1','1'),('2','2'),('3','3'),('4','4')]
            pl_args = ['dialog','--stdout','--title','Players','--menu','Choose number of players:','15','40','4']
            for p in players_options:
                pl_args.extend(p)
            with open('/dev/tty') as tty:
                pr = subprocess.run(pl_args,capture_output=True,text=True,stdin=tty)
            if pr.returncode==0 and pr.stdout.strip():
                filters['players']=pr.stdout.strip()
        elif choice=='6':
            val = get_input_from_osk("Starting Letter","Enter a letter:")
            if val:
                val=val[0]
                filters['letter']=val
        elif choice=='7':
            val = get_input_from_osk("Search by Name","Enter name substring:")
            if val:
                filters['name']=val
    return filters

def select_games_for_deletion(system_name,system_dir,games):
    if len(games)>100:
        if ask_yes_no("Would you like to apply filters to help narrow your selection?"):
            filters = select_filter(games)
            filtered = apply_filters(games,filters)
        else:
            filtered = games
    else:
        filtered = games

    if not filtered:
        show_msgbox("No games found after applying filters.")
        return []
    dialog_args = [
        'dialog','--stdout','--title','Select Games to Delete','--checklist',
        "Select the games to delete:\n\nBack Button: Check Selection\nSelect Button: Save and Confirm Choices",
        '25','100','20'
    ]
    for g in filtered:
        sz = format_size(get_game_size(system_dir,g))
        dialog_args.extend([g['rom_path'],f"{g['name']} ({sz})",'off'])
    with open('/dev/tty') as tty:
        result = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
    if result.returncode!=0:
        return []
    selected_roms = result.stdout.strip().split()
    selected_games = [g for g in filtered if g['rom_path'] in selected_roms]
    return selected_games

def bulk_deletion_menu(games, system_dir, system_name):
    opts = [
        ('1','Delete All Games in This System'),
        ('2','Delete Games in This System by Name Pattern'),
        ('3','Delete Games in This System by Manual Selection'),
        ('4','Cancel')
    ]
    da = ['dialog','--stdout','--title','Bulk Deletion','--menu',
          'Choose a bulk deletion method:',
          '20','60','4']
    for o in opts:
        da.extend(o)
    with open('/dev/tty') as tty:
        r=subprocess.run(da,capture_output=True,text=True,stdin=tty)
    if r.returncode!=0:
        return [],0
    choice=r.stdout.strip()
    if choice=='1':
        if ask_yes_no(f"Are you sure you want to delete ALL games from the {system_name} system?\nThis cannot be undone."):
            return games, sum(get_game_size(system_dir,g) for g in games)
        return [],0
    elif choice=='2':
        pattern = get_input_from_osk("Delete by Pattern","Enter pattern substring:")
        if not pattern:
            show_msgbox("No pattern entered. Cancelled.")
            return [],0
        matched = [g for g in games if pattern.lower() in g['name'].lower()]
        if not matched:
            show_msgbox("No games matched that pattern.")
            return [],0
        if ask_yes_no(f"Delete {len(matched)} games from the {system_name} system matching '{pattern}'?"):
            return matched, sum(get_game_size(system_dir,m) for m in matched)
        return [],0
    elif choice=='3':
        dialog_args = [
            'dialog','--stdout','--title','Select Games to Delete','--checklist',
            "Select games to delete:\n\nBack Button: Check Selection\nSelect Button: Save and Confirm Choices",
            '25','100','20'
        ]
        for g in games:
            sz = format_size(get_game_size(system_dir,g))
            dialog_args.extend([g['rom_path'],f"{g['name']} ({sz})",'off'])
        with open('/dev/tty') as tty:
            rs = subprocess.run(dialog_args,capture_output=True,text=True,stdin=tty)
        if rs.returncode!=0:
            return [],0
        sel = rs.stdout.strip().split()
        sgs = [gg for gg in games if gg['rom_path'] in sel]
        if not sgs:
            return [],0
        if ask_yes_no(f"Selected {len(sgs)} games from the {system_name} system for deletion. Confirm?"):
            return sgs, sum(get_game_size(system_dir,gg) for gg in sgs)
        else:
            show_msgbox("Bulk deletion cancelled.")
            return [],0
    else:
        return [],0

def delete_game_files(system_dir,game,system_name):
    """
    Freed is how many bytes we would have freed if DRY_RUN were False.
    We'll *log* the actions, but only remove the files if DRY_RUN==False.
    """
    freed=0
    deleted_files=[]
    def del_file(fp):
        nonlocal freed
        if os.path.exists(fp):
            sz=os.path.getsize(fp)
            freed+=sz
            if DRY_RUN:
                log_action(f"[DRY RUN] Would delete: {fp}")
            else:
                os.remove(fp)
                log_action(f"Deleted file: {fp}")

            deleted_files.append(fp)

    romp = os.path.join(system_dir,game.get('rom_path',''))
    if romp and os.path.exists(romp):
        del_file(romp)
        # Additional logic if Naomi or NEOGEOCD, omitted

    if game.get('image_path'):
        ip = os.path.join(system_dir,game['image_path'])
        if os.path.exists(ip):
            del_file(ip)

    if game.get('video_path'):
        vp = os.path.join(system_dir,game['video_path'])
        if os.path.exists(vp):
            del_file(vp)

    return freed,deleted_files

def write_gamelist(tree,gamelist_path):
    if DRY_RUN:
        log_action(f"[DRY RUN] Would rewrite gamelist.xml: {gamelist_path}")
    else:
        tree.write(gamelist_path, encoding='utf-8',xml_declaration=True)

def delete_entire_system(system_name, system_dir):
    """
    Freed is how many bytes we would have freed if DRY_RUN were False.
    We'll *log* the actions, but only remove the files if DRY_RUN==False.
    """
    total_freed=0
    if DRY_RUN:
        log_action(f"[DRY RUN] Would delete entire system: {system_name} at {system_dir}")
        # Just calculate total size
        for root,dirs,files in os.walk(system_dir):
            for f in files:
                fp = os.path.join(root,f)
                total_freed+= os.path.getsize(fp)
    else:
        # Actually remove
        if os.path.exists(os.path.join(system_dir,'gamelist.xml')):
            os.remove(os.path.join(system_dir,'gamelist.xml'))
        for root,dirs,files in os.walk(system_dir):
            for f in files:
                fp = os.path.join(root,f)
                sz=os.path.getsize(fp)
                os.remove(fp)
                total_freed+=sz
        log_action(f"Deleted entire system: {system_name}, Freed {format_size(total_freed)}")

    return total_freed

def prompt_main_menu():
    opts = [
        ('1','View Current Storage Usage'),
        ('2','Select System to Manage'),
        ('3','Exit')
    ]
    da = ['dialog','--stdout','--title','Main Menu','--menu','Choose an option:','20','60','3']
    for o in opts:
        da.extend(o)
    with open('/dev/tty') as tty:
        r=subprocess.run(da,capture_output=True,text=True,stdin=tty)
    if r.returncode!=0:
        return 'exit'
    return r.stdout.strip()

def prompt_game_management():
    opts=[
        ('1','Selective Deletion'),
        ('2','Bulk Deletion'),
        ('3','Undo Last Action'),
        ('4','Clear All Filters'),
        ('5','Return to Main Menu')
    ]
    da = ['dialog','--stdout','--title','Game Management','--menu',
          'Choose a deletion method:',
          '20','60','5']
    for o in opts:
        da.extend(o)
    with open('/dev/tty') as tty:
        rr = subprocess.run(da,capture_output=True,text=True,stdin=tty)
    if rr.returncode!=0:
        return None
    return rr.stdout.strip()

def show_storage_usage():
    used,free,total = get_disk_usage(ROMS_DIR)
    msg=(
        f"Current Storage Usage:\n\n"
        f"Used: {format_size(used)}\n"
        f"Free: {format_size(free)}\n"
        f"Total: {format_size(total)}"
    )
    show_msgbox(msg)

def summarize_deletions(deletions):
    total_freed= sum(x['size'] for x in deletions['games']) + sum(x['size'] for x in deletions['systems'])
    lines=[]
    lines.append("Summary of Pending Deletions:\n")
    if deletions['systems']:
        lines.append("Entire Systems to be Deleted:")
        for s in deletions['systems']:
            lines.append(f"  - {s['system_name']} ({format_size(s['size'])})")
    if deletions['games']:
        lines.append("\nIndividual Games to be Deleted:")
        sysmap={}
        for g in deletions['games']:
            sysmap.setdefault(g['system_name'],[]).append(g)
        for sysn,gl in sysmap.items():
            lines.append(f"  From {sysn}:")
            for gg in gl:
                lines.append(f"    {gg['game_name']} ({format_size(gg['size'])})")

    lines.append(f"\nTotal Space to be Freed: {format_size(total_freed)}")
    return "\n".join(lines),total_freed

def final_confirmation(deletions):
    summary,total_freed = summarize_deletions(deletions)
    summary+= "\n\nPlease re-enter the password to confirm these changes."
    show_msgbox(summary, height=30, width=80)
    if not password_prompt("Enter password to confirm deletions:", final=True):
        return False
    return True
    
# -------------- perform_deletions WITH GAUGE + DRY_RUN --------------
def perform_deletions(deletions):
    """
    Replaces your original code which used an infobox with a gauge-based approach.
    Also respects DRY_RUN.
    """
    # Gather all items (systems + games) into a single list
    items_to_delete = []
    for s in deletions['systems']:
        items_to_delete.append(('system', s))
    for g in deletions['games']:
        items_to_delete.append(('game', g))

    total_items = len(items_to_delete)
    if total_items == 0:
        show_msgbox("No items to delete. Nothing changed.")
        return

    # Instead of infobox, we do gauge
    gauge_cmd = [
        "dialog",
        "--gauge", 
        "Applying Changes...\n\nThis may take a while, please wait.", 
        "10", "50", "0"
    ]
    with subprocess.Popen(gauge_cmd, stdin=subprocess.PIPE, text=True) as gauge_proc:
        current_index = 0
        total_freed = 0
        for item_type, item_data in items_to_delete:
            current_index += 1
            percent = math.floor((current_index / total_items) * 100)

            # Update gauge
            gauge_proc.stdin.write(f"{percent}\nXXX\n")
            if item_type == 'system':
                gauge_proc.stdin.write(f"Deleting system: {item_data['system_name']}  ({current_index}/{total_items})\n")
            else:
                gauge_proc.stdin.write(f"Deleting game: {item_data['game_name']}  ({current_index}/{total_items})\n")
            gauge_proc.stdin.write("XXX\n")
            gauge_proc.stdin.flush()

            if item_type == 'system':
                # item_data = { 'system_name':..., 'dir_name':..., 'size':... }
                system_dir = os.path.join(ROMS_DIR, item_data['dir_name'])
                freed = delete_entire_system(item_data['system_name'], system_dir)
                total_freed += freed
            else:
                # item_data = { 'system_name':..., 'dir_name':..., 'game_name':..., 'rom_path':..., 'size':... }
                sd = os.path.join(ROMS_DIR, item_data['dir_name'])
                freed, _ = delete_game_files(sd, {
                    'rom_path': item_data['rom_path'],
                    'image_path': None,
                    'video_path': None,
                    'game_name': item_data['game_name']
                }, item_data['system_name'])
                total_freed += freed

        # Once complete, show 100% and final text
        gauge_proc.stdin.write("100\nXXX\nDeletion complete!\nXXX\n")
        gauge_proc.stdin.flush()
        gauge_proc.stdin.close()
        gauge_proc.wait()

    # If DRY_RUN, skip actual reboot
    if DRY_RUN:
        show_msgbox(f"[DRY RUN] Deletions simulated.\n\nWould have freed: {format_size(total_freed)}\nNo reboot performed.")
        return
    else:
        show_msgbox(f"Deletion Complete.\n\nSystem will reboot in 5 seconds to finalize changes.\nFreed: {format_size(total_freed)}")
        subprocess.run(['sleep','5'])
        subprocess.run(['sudo','reboot'])


def main():
    disclaimer = (
        "WARNING: This tool allows you to permanently delete games and entire systems.\n\n"
        "These changes cannot be undone.\n\n"
        "You must enter the password 'iagree' to proceed.\n\n"
        "By entering this password, you understand and agree that Simple Arcades cannot and will not provide free technical support nor\n"
        "restore deleted games/systems. Furthermore, deleted games and/or systems is not covered under our included limited warranty.\n\n"
        "Please proceed with caution."
    )
    show_msgbox(disclaimer, height=20, width=70, title="Disclaimer")

    # Prompt for password at the start, with initial=True
    result = password_prompt("Enter password to proceed:", initial=True)
    if result is None:
        # User chose to exit at the initial password prompt
        show_msgbox("No changes were made. Exiting.")
        sys.exit(0)
    elif result == False:
        # User failed attempts or canceled without confirming to proceed
        show_msgbox("No changes were made. Exiting.")
        sys.exit(0)
    # If result == True, password correct, continue

    made_changes=False
    undo_stack=[]
    pending_deletions={'systems':[],'games':[]}

    while True:
        choice = prompt_main_menu()
        if choice=='exit' or choice=='3':
            if made_changes:
                if (pending_deletions['systems'] or pending_deletions['games']):
                    # Ask if finalize now
                    if ask_yes_no("You have pending deletions. Do you want to review and finalize changes now?"):
                        summary,total_freed = summarize_deletions(pending_deletions)
                        show_msgbox(summary, height=30, width=80)
                        if final_confirmation(pending_deletions):
                            now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
                            log_path = os.path.join(LOG_DIR,f"deletion_log_{now}.txt")
                            with open(log_path,'w') as lf:
                                global SESSION_LOG
                                SESSION_LOG = lf
                                for s in pending_deletions['systems']:
                                    log_action(f"System to delete: {s['system_name']} total {format_size(s['size'])}")
                                for g in pending_deletions['games']:
                                    log_action(f"Game to delete: {g['game_name']} from {g['system_name']} size {format_size(g['size'])}")
                                log_action(f"Total space to free: {format_size(total_freed)}")
                            perform_deletions(pending_deletions)
                    else:
                        show_msgbox("No changes were made. Exiting.")
                else:
                    show_msgbox("No changes were applied. Exiting.")
            sys.exit(0)
        elif choice=='1':
            show_storage_usage()
        elif choice=='2':
            systems = get_systems()
            s = select_system(systems)
            if not s:
                continue
            system_dir = os.path.join(ROMS_DIR,s['dir_name'])
            if not os.path.exists(s['gamelist_path']):
                show_msgbox("Gamelist not found. Returning to menu.")
                continue
            sn,gm,tree,root = parse_gamelist(s['gamelist_path'])

            while True:
                gchoice = prompt_game_management()
                if gchoice is None or gchoice=='5':
                    break
                if gchoice=='1':
                    selected_games = select_games_for_deletion(sn,system_dir,gm)
                    if not selected_games:
                        continue
                    space = sum(get_game_size(system_dir,sg) for sg in selected_games)
                    if ask_yes_no(f"You have selected {len(selected_games)} game(s) for deletion from {sn}, freeing {format_size(space)}.\nConfirm?"):
                        for sg in selected_games:
                            sz = get_game_size(system_dir,sg)
                            pending_deletions['games'].append({
                                'system_name': sn,
                                'dir_name': s['dir_name'],
                                'game_name': sg['name'],
                                'rom_path': sg['rom_path'],
                                'size': sz
                            })
                        undo_stack.append(('games',selected_games,s['dir_name'],sn))
                        made_changes=True
                    else:
                        show_msgbox("Deletion cancelled.")
                elif gchoice=='2':
                    selected_games,space = bulk_deletion_menu(gm,system_dir,sn)
                    if not selected_games:
                        continue
                    if ask_yes_no(f"Selected {len(selected_games)} game(s) from {sn} for deletion, freeing {format_size(space)}.\nConfirm?"):
                        for sg in selected_games:
                            sz = get_game_size(system_dir,sg)
                            pending_deletions['games'].append({
                                'system_name': sn,
                                'dir_name': s['dir_name'],
                                'game_name': sg['name'],
                                'rom_path': sg['rom_path'],
                                'size': sz
                            })
                        undo_stack.append(('games',selected_games,s['dir_name'],sn))
                        made_changes=True
                    else:
                        show_msgbox("Bulk deletion cancelled.")
                elif gchoice=='3':
                    if undo_stack:
                        last_action = undo_stack.pop()
                        if last_action[0]=='games':
                            for ggg in last_action[1]:
                                pending_deletions['games'] = [xx for xx in pending_deletions['games'] if not (xx['dir_name']==last_action[2] and xx['rom_path']==ggg['rom_path'])]
                        elif last_action[0]=='system':
                            pending_deletions['systems'] = [xx for xx in pending_deletions['systems'] if xx['dir_name']!=last_action[1]]
                        show_msgbox("Last action undone.")
                    else:
                        show_msgbox("No actions to undo.")
                elif gchoice=='4':
                    show_msgbox("Filters cleared.")
                else:
                    pass

                # Check if entire system is effectively deleted
                gamelist_size = sum(get_game_size(system_dir,gg) for gg in gm)
                chosen_game_size = sum(x['size'] for x in pending_deletions['games'] if x['dir_name']==s['dir_name'])
                if chosen_game_size==gamelist_size and gamelist_size>0:
                    pending_deletions['games'] = [x for x in pending_deletions['games'] if x['dir_name']!=s['dir_name']]
                    pending_deletions['systems'].append({
                        'system_name': sn,
                        'dir_name': s['dir_name'],
                        'size': gamelist_size
                    })
                    undo_stack.clear()
                    undo_stack.append(('system',s['dir_name']))
                    made_changes=True
        else:
            pass

if __name__ == "__main__":
    main()