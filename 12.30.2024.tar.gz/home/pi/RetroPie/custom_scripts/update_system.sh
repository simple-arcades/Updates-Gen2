#!/bin/bash

# Ensure the script is run as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root."
    exit 1
fi

# Prevent Multiple Instances
LOCKFILE="/var/run/update_system.lock"

if [ -e "$LOCKFILE" ] && kill -0 "$(cat "$LOCKFILE")" 2>/dev/null; then
    echo "Update script is already running."
    exit 1
fi

trap "cleanup; exit" INT TERM EXIT
echo $$ > "$LOCKFILE"

# Configuration Variables
UPDATE_BASE_URL="https://raw.githubusercontent.com/simple-arcades/Updates-Gen2/main"
LOCAL_VERSION_FILE="/home/pi/RetroPie/custom_scripts/logs/update_version.log"
TEMP_UPDATE_DIR="/tmp/update_package_$$"
LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/update_system.log"

# Define directories with desired ownership and permissions
declare -A DIR_PERMISSIONS=(
	["/home/pi/RetroPie"]="pi:pi 755"
	["/home/pi/pixelcade"]="pi:pi 755"
	["/home/pi/screenshots"]="pi:pi 755"
	["/home/pi/music_settings"]="pi:pi 755"
	["/opt/retropie/configs"]="pi:pi 755"
	["/opt/retropie/supplementary"]="root:root 755"
	["/opt/retropie/libretrocores"]="root:root 755"
    ["/etc/emulationstation"]="root:root 755"
	["/boot"]="root:root 755"
    # Add more directories as needed
)

# Define files with desired ownership and permissions
declare -A FILE_PERMISSIONS=(
    ["/home/pi/RetroPie/custom_scripts/logs/update_version.log"]="pi:pi 755"
    # Add more files as needed
)

# Helper Functions

# Display a message box using dialog
show_message() {
    local message="$1"
    dialog --ok-button "OK" --msgbox "$message" 10 50
}

# Log actions with timestamps
log_update() {
    local message="$1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $message" >> "$LOG_FILE"
}

# Ensure that a file exists; if not, create it with a default value
ensure_file_exists() {
    local file_path="$1"
    if [ ! -f "$file_path" ]; then
        touch "$file_path"
        echo "0.0.0" > "$file_path"  # Initialize with a base version
        log_update "Initialized $file_path with version 0.0.0"
    fi
}

# Function to set directory ownership and permissions
set_dir_permissions() {
    for dir in "${!DIR_PERMISSIONS[@]}"; do
        IFS=' ' read -r owner_group perm <<< "${DIR_PERMISSIONS[$dir]}"
        IFS=':' read -r owner group <<< "$owner_group"
        if [ -d "$dir" ]; then
            chown "$owner":"$group" "$dir"
            chmod "$perm" "$dir"
            log_update "Set ownership to $owner:$group and permissions to $perm for directory: $dir"
        else
            log_update "Directory not found: $dir"
        fi
    done
}

# Function to set ownership and permissions for new files and directories after rsync
set_permissions_for_new_entries() {
    log_update "Starting to set permissions for new files and directories based on parent directory"

    find /home/pi/RetroPie -type f -newer /tmp/update_marker -print0 | while IFS= read -r -d '' entry; do
        dir=$(dirname "$entry")
        if [[ ${DIR_PERMISSIONS[$dir]+_} ]]; then
            IFS=' ' read -r owner_group perm <<< "${DIR_PERMISSIONS[$dir]}"
            IFS=':' read -r owner group <<< "$owner_group"
            chown "$owner":"$group" "$entry"
            chmod "$perm" "$entry"
            log_update "Set ownership to $owner:$group and permissions to $perm for new entry: $entry in directory: $dir"
        else
            log_update "No permissions set for new entry: $entry in directory: $dir"
        fi
    done

    log_update "Completed setting permissions for new files and directories"
}

# Function to clean up temporary files and lockfile
cleanup() {
    rm -rf "$TEMP_UPDATE_DIR" /tmp/update.tar.gz /tmp/list.txt /tmp/update.sha256
    rm -f "$LOCKFILE"
    log_update "Cleaned up temporary files and removed lockfile."
}

# Function to verify checksum
verify_checksum() {
    local update="$1"
    local checksum_url="$UPDATE_BASE_URL/${update%.tar.gz}.sha256"
    log_update "Downloading checksum for $update from $checksum_url"
    wget -q -O /tmp/update.sha256 "$checksum_url"
    if [ $? -ne 0 ] || [ ! -f /tmp/update.sha256 ]; then
        log_update "Failed to download checksum for $update."
        show_message "Failed to download checksum for $update. Update aborted."
        return 1
    fi

    sha256sum -c /tmp/update.sha256 > /dev/null 2>&1
    if [ $? -ne 0 ]; then
        log_update "Checksum verification failed for $update."
        show_message "Checksum verification failed for $update. Update aborted."
        return 1
    fi

    log_update "Checksum verification passed for $update."
    return 0
}

# Function to backup RetroPie directory
backup_retro_pie() {
    local backup_dir="/home/pi/RetroPie_backup_$(date '+%Y%m%d%H%M%S')"
    mkdir -p "$backup_dir"
    log_update "Creating backup of RetroPie directory at $backup_dir"
    rsync -av --progress /home/pi/RetroPie/ "$backup_dir/"
    if [ $? -eq 0 ]; then
        log_update "Backup of RetroPie created successfully at $backup_dir"
    else
        log_update "Failed to create backup of RetroPie."
        show_message "Failed to create backup. Update aborted."
        exit 1
    fi
}

# Fetch Available Updates
fetch_updates() {
    log_update "Fetching available updates from $UPDATE_BASE_URL/list.txt"
    wget -q -O /tmp/list.txt "$UPDATE_BASE_URL/list.txt"
    if [ $? -ne 0 ] || [ ! -f /tmp/list.txt ]; then
        log_update "Failed to fetch the update list. Internet connection might be required."
        show_message "Failed to fetch the update list. Please check your internet connection."
        return 1
    fi
    cat /tmp/list.txt
    return 0
}

# Apply Updates
apply_updates() {
    local updates=("$@")
    local current_version
    current_version=$(cat "$LOCAL_VERSION_FILE")
    local updates_applied=0

    # Count how many updates are actually "newer" than current_version
    # so the gauge knows how many steps there are.
    local valid_updates=()
    for u in "${updates[@]}"; do
        if [[ "$u" == "$current_version" || "$u" < "$current_version" ]]; then
            log_update "Skipping already applied or older update: $u"
        else
            valid_updates+=("$u")
        fi
    done

    local total_updates=${#valid_updates[@]}
    if [ $total_updates -eq 0 ]; then
        log_update "No valid updates to apply."
        return 1
    fi

    # We'll feed progress info to dialog --gauge via a subshell
    (
        local i=0
        for update in "${valid_updates[@]}"; do
            ((i++))

            # Just before we process the update, show progress
            local percent=$(( i * 100 / total_updates ))
            echo "$percent"
            echo "XXX"
            echo "Applying update: $update ($i/$total_updates)"
            echo "XXX"
            sleep 1  # Just to visually see the gauge move (optional)

            log_update "Processing update: $update"

            # Download update
            log_update "Downloading update package: $update"
            wget -O /tmp/update.tar.gz "$UPDATE_BASE_URL/$update" >/dev/null 2>&1
            if [ $? -ne 0 ]; then
                log_update "Failed to download $update."
                rm -rf "$TEMP_UPDATE_DIR"
                echo "100"
                echo "XXX"
                echo "Failed to download $update"
                echo "XXX"
                exit 1
            fi

            # Extract update
            log_update "Extracting update package: $update"
            mkdir -p "$TEMP_UPDATE_DIR"
            tar -xzf /tmp/update.tar.gz -C "$TEMP_UPDATE_DIR"
            if [ $? -ne 0 ]; then
                log_update "Failed to extract $update."
                rm -rf "$TEMP_UPDATE_DIR"
                echo "100"
                echo "XXX"
                echo "Failed to extract $update"
                echo "XXX"
                exit 1
            fi

            # Validate
            if [ ! -d "$TEMP_UPDATE_DIR/home/pi/RetroPie" ]; then
                log_update "Update package $update is missing the RetroPie directory."
                rm -rf "$TEMP_UPDATE_DIR" /tmp/update.tar.gz
                echo "100"
                echo "XXX"
                echo "Invalid update package: $update"
                echo "XXX"
                exit 1
            fi

            # Process delete_list.txt if present
            if [ -f "$TEMP_UPDATE_DIR/delete_list.txt" ]; then
                log_update "Processing delete_list.txt for update: $update"
                while read -r file; do
                    if [ -f "$file" ]; then
                        rm -f "$file"
                        log_update "Deleted file as per delete_list.txt: $file"
                    else
                        log_update "File listed for deletion not found: $file"
                    fi
                done < "$TEMP_UPDATE_DIR/delete_list.txt"
            fi

            # Marker file to track newly added files
            touch /tmp/update_marker

            # rsync without preserving ownership (quiet mode to avoid flooding the gauge)
            log_update "Applying update files to /"
            rsync -r "$TEMP_UPDATE_DIR/" / >/dev/null 2>&1
            if [ $? -ne 0 ]; then
                log_update "Failed to synchronize update files for $update."
                rm -rf "$TEMP_UPDATE_DIR" /tmp/update.tar.gz
                echo "100"
                echo "XXX"
                echo "Failed to apply $update"
                echo "XXX"
                exit 1
            fi

            # Update local version file
            echo "$update" > "$LOCAL_VERSION_FILE"
            log_update "Update $update applied successfully."
            updates_applied=1

            rm -rf "$TEMP_UPDATE_DIR" /tmp/update.tar.gz
        done

        # If we completed the loop, set final progress to 100%
        echo "100"
        echo "XXX"
        echo "All selected updates applied successfully!"
        echo "XXX"

    ) | dialog --gauge "Applying updates..." 10 60 0

    # If the gauge subshell exit code is non-zero => we had an error
    local exit_status=$?
    if [ $exit_status -ne 0 ]; then
        show_message "An error occurred. Please check the update log."
        return 1
    fi

    if [ $updates_applied -eq 1 ]; then
        # Set directory permissions
        set_dir_permissions
        # Set permissions for new entries
        set_permissions_for_new_entries
        return 0
    else
        return 1
    fi
}

# System Updates Menu
system_updates_menu() {
    while true; do
        OPTION=$(dialog --stdout --title "System Updates" --menu \
            "WARNING: Your arcade must be connected to WiFi for updates to download." \
            15 60 3 \
            1 "Check for Updates" \
            2 "View Update Log" \
            3 "View Current Version")

        [[ $? -ne 0 ]] && return  # Cancel pressed, go back

        case $OPTION in
            1)
                log_update "User selected 'Check for Updates'."
                updates=$(fetch_updates)
                if [ $? -ne 0 ]; then
                    continue
                fi

                current_version=$(cat "$LOCAL_VERSION_FILE")
                log_update "Current system version: $current_version"

                # Sort and filter updates so only those newer than current_version remain
                updates=$(echo "$updates" | sort -V | awk -v cv="$current_version" '$1 > cv')

                if [ -z "$updates" ]; then
                    show_message "Your system is up-to-date! No updates available."
                    log_update "No updates available."
                else
                    # Prepare checklist options
                    checklist_options=()
                    while read -r update; do
                        checklist_options+=("$update" "$update" "off")
                    done <<< "$updates"

                    # Show checklist for user to select updates
                    choices=$(dialog --stdout --title "Available Updates" --checklist \
                        "Select Updates to apply:\n\n(Note: Back button ticks highlighted selection)" \
                        20 60 10 \
                        "${checklist_options[@]}")

                    [[ $? -ne 0 ]] && continue  # Cancel pressed

                    # Parse selected updates
                    selected_updates=($(echo "$choices" | tr -d '"' | tr ' ' '\n'))

                    if [ ${#selected_updates[@]} -eq 0 ]; then
                        show_message "No updates selected."
                        log_update "No updates were selected by the user."
                    else
                        # Sort the selected updates to ensure proper order
                        sorted_updates=($(printf '%s\n' "${selected_updates[@]}" | sort -V))
                        filtered_updates=()

                        # Double-check filtering, just in case
                        for u in "${sorted_updates[@]}"; do
                            if [[ "$u" == "$current_version" || "$u" < "$current_version" ]]; then
                                log_update "Skipping already applied or older update: $u"
                                continue
                            fi
                            filtered_updates+=("$u")
                        done

                        if [ ${#filtered_updates[@]} -eq 0 ]; then
                            show_message "No valid updates to apply."
                            log_update "No valid updates were selected after filtering."
                        else
                            apply_updates "${filtered_updates[@]}"
                            if [ $? -eq 0 ]; then
                                dialog --yesno "Updates applied successfully. Do you want to reboot now?" 10 50
                                if [ $? -eq 0 ]; then
                                    show_message "Rebooting your arcade."
                                    log_update "Initiating system reboot."
                                    reboot
                                else
                                    show_message "Reboot canceled. Please reboot manually to apply updates."
                                    log_update "User chose to postpone reboot after updates."
                                fi
                            else
                                show_message "Failed to apply updates. Please check the update log."
                                log_update "Failed to apply updates. Check the log for details."
                            fi
                        fi
                    fi
                fi
                ;;
            2)
                log_update "User selected 'View Update Log'."
                if [ ! -f "$LOG_FILE" ]; then
                    show_message "No updates have been applied yet."
                    log_update "Update log file does not exist."
                else
                    dialog --ok-button "OK" --title "Update Log" --textbox "$LOG_FILE" 20 60
                fi
                ;;
            3)
                log_update "User selected 'View Current Version'."
                current_version=$(cat "$LOCAL_VERSION_FILE")
                show_message "Your current system version is: $current_version"
                ;;
        esac
    done
}

# Run the System Updates Menu
system_updates_menu

# Clean up lockfile upon script exit
cleanup