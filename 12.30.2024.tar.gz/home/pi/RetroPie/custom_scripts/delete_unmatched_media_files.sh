#!/usr/bin/env bash
#
# delete_unmatched_media_files.sh
#
# Scans each system directory under ~/RetroPie/roms, finds media files
# (images / videos) **not** referenced in gamelist.xml, and asks what
# action to take (delete / move / skip).
#
# USAGE:
#   1) chmod +x delete_unmatched_media_files.sh
#   2) ./delete_unmatched_media_files.sh
#

############################################
# CONFIGURATION
############################################

ROMS_DIR="$HOME/RetroPie/roms"

# Folder to move unreferenced media files to, if the user chooses "M".
UNMATCHED_DIR="$HOME/RetroPie/custom_scripts/unmatched_media_files"

# If your gamelist references images like ./media/images/*.png
# and videos like ./media/videos/*.mp4, these are the subfolders we'll check.
IMAGES_SUBPATH="media/images"
VIDEOS_SUBPATH="media/videos"

# If you prefer a 'dry run' by default, set DRY_RUN=1. 
DRY_RUN=1

############################################
# INTERNAL VARIABLES
############################################
declare -a UNMATCHED_FILES=()

############################################
# FUNCTION: Gather referenced media from gamelist.xml
############################################
function gather_referenced_paths() {
  local gamelist_file="$1"
  local -n ref_images=$2    # "Pass by reference" to fill an array
  local -n ref_videos=$3

  # Clear them first
  ref_images=()
  ref_videos=()

  # Extract all <image> tags in the gamelist
  while IFS= read -r image_path; do
    # Unescape XML entities (just &amp; for now)
    # So "Sonic &amp; Knuckles.png" => "Sonic & Knuckles.png"
    image_path="$(echo "$image_path" | sed 's/\&amp;/\&/g')"

    # Remove leading "./" if any:
    image_path="${image_path#./}"
    ref_images+=( "$image_path" )
  done < <(grep -oP '(?<=<image>).*?(?=</image>)' "$gamelist_file")

  # Extract all <video> tags
  while IFS= read -r video_path; do
    video_path="$(echo "$video_path" | sed 's/\&amp;/\&/g')"
    video_path="${video_path#./}"
    ref_videos+=( "$video_path" )
  done < <(grep -oP '(?<=<video>).*?(?=</video>)' "$gamelist_file")
}

############################################
# FUNCTION: Process a single system folder
############################################
function process_system_folder() {
  local system_dir="$1"
  local gamelist="$system_dir/gamelist.xml"

  # If there's no gamelist, skip
  if [ ! -f "$gamelist" ]; then
    echo "No gamelist.xml in $system_dir; skipping."
    return
  fi

  # Gather arrays for images & videos
  local -a IMAGES_IN_GAMELIST
  local -a VIDEOS_IN_GAMELIST
  gather_referenced_paths "$gamelist" IMAGES_IN_GAMELIST VIDEOS_IN_GAMELIST

  # For images & videos, find any that are not referenced
  local images_path="$system_dir/$IMAGES_SUBPATH"
  local videos_path="$system_dir/$VIDEOS_SUBPATH"

  # 1) Images
  if [ -d "$images_path" ]; then
    while IFS= read -r file; do
      # Build relative path from the system_dir
      # e.g. media/images/contra.png
      local rel_path="${file#"$system_dir/"}"

      # Check if rel_path is in IMAGES_IN_GAMELIST
      if [[ ! " ${IMAGES_IN_GAMELIST[*]} " =~ " $rel_path " ]]; then
        UNMATCHED_FILES+=( "$file" )
      fi
    done < <(find "$images_path" -type f)
  fi

  # 2) Videos
  if [ -d "$videos_path" ]; then
    while IFS= read -r file; do
      local rel_path="${file#"$system_dir/"}"

      # Check if rel_path is in VIDEOS_IN_GAMELIST
      if [[ ! " ${VIDEOS_IN_GAMELIST[*]} " =~ " $rel_path " ]]; then
        UNMATCHED_FILES+=( "$file" )
      fi
    done < <(find "$videos_path" -type f)
  fi
}

############################################
# FUNCTION: Summarize and prompt user
############################################
function finalize_unmatched_files() {
  if [ ${#UNMATCHED_FILES[@]} -eq 0 ]; then
    echo "No unreferenced media files found!"
    return 0
  fi

  echo "Found ${#UNMATCHED_FILES[@]} unreferenced media files:"
  echo "------------------------------------------------------"
  for f in "${UNMATCHED_FILES[@]}"; do
    echo "$f"
  done
  echo "------------------------------------------------------"

  # Calculate total size
  # We'll feed all file paths to 'du -ch' in one shot for a nice summary.
  echo "Calculating total size..."
  # If there's a lot of files, we must pass them carefully to du.
  # One approach: store them in a temp file, then 'du' that list.
  tmpfile=$(mktemp)
  for f in "${UNMATCHED_FILES[@]}"; do
    echo "$f" >> "$tmpfile"
  done
  # du -ch with -s won't show individual lines, so we do:
  du -ch --files0-from=<(tr '\n' '\0' < "$tmpfile") | tail -n1
  rm -f "$tmpfile"

  # Prompt user
  echo ""
  echo "What would you like to do with these files?"
  echo "[D] Delete them permanently"
  echo "[M] Move them into $UNMATCHED_DIR (maintaining folder structure)"
  echo "[S] Skip (do nothing)"
  read -p "Enter D, M, or S: " -n1 choice
  echo ""
  choice="${choice^^}"  # uppercase

  case "$choice" in
    D)
      echo "You chose DELETE."
      if [ "$DRY_RUN" -eq 1 ]; then
        echo "DRY_RUN=1 is set, so we won't actually delete. (Would have deleted ${#UNMATCHED_FILES[@]} files.)"
        return 0
      fi
      delete_files
      ;;
    M)
      echo "You chose MOVE -> $UNMATCHED_DIR."
      if [ "$DRY_RUN" -eq 1 ]; then
        echo "DRY_RUN=1 is set, so we won't actually move. (Would have moved ${#UNMATCHED_FILES[@]} files.)"
        return 0
      fi
      move_files
      ;;
    *)
      echo "Skipping cleanup. No changes made."
      ;;
  esac
}

############################################
# FUNCTION: Delete unmatched files
############################################
function delete_files() {
  for f in "${UNMATCHED_FILES[@]}"; do
    if [ -f "$f" ]; then
      echo "Removing $f"
      rm -f "$f"
    fi
  done
  echo "All unreferenced media files deleted."
}

############################################
# FUNCTION: Move unmatched files
############################################
function move_files() {
  echo "Moving files to $UNMATCHED_DIR ..."
  for f in "${UNMATCHED_FILES[@]}"; do
    if [ -f "$f" ]; then
      # Build a new path. E.g. if $f is /home/pi/RetroPie/roms/nes/media/images/Contra.png
      # then relative is: roms/nes/media/images/Contra.png
      local rel_path="${f#"$HOME/"}" 
      # You might prefer to remove "RetroPie/" part too, but let's keep it consistent so it's easy to see the structure
      local target="$UNMATCHED_DIR/$rel_path"

      # Make sure the target directory exists:
      mkdir -p "$(dirname "$target")"

      echo "Moving: $f -> $target"
      mv "$f" "$target"
    fi
  done
  echo "All unmatched files moved successfully!"
}

############################################
# MAIN
############################################

# 1) Gather unmatched from each system directory
for system_dir in "$ROMS_DIR"/*; do
  [ -d "$system_dir" ] || continue
  echo "Scanning: $system_dir ..."
  process_system_folder "$system_dir"
done

# 2) Summarize, confirm, and act (delete/move/skip)
finalize_unmatched_files
