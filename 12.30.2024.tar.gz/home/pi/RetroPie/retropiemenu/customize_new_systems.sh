#!/bin/bash

# Prevent multiple instances
LOCKFILE="/var/run/customize_new_systems.lock"

if [ -e "$LOCKFILE" ] && kill -0 "$(cat "$LOCKFILE")" 2>/dev/null; then
    echo "Script is already running."
    exit 1
fi

trap "rm -f $LOCKFILE; exit" INT TERM EXIT
echo $$ > "$LOCKFILE"

# Constants
LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/arcade_setup.log"
MARKER_FILE="/home/pi/RetroPie/custom_scripts/logs/arcade_configured.log"
ROM_DIR="/home/pi/RetroPie/roms/mame-libretro"
EMULATIONSTATION_CONFIG="/opt/retropie/configs/all/emulationstation"

# Logging function
log_action() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

###############################################################################
# NEW SECTION: CLEANUP UNREFERENCED MEDIA
###############################################################################
# If set to 1, script will *not* actually remove/move any files, just log what
# it *would* do. Great for testing.
DRY_RUN=0

# Folder where we move unreferenced media if the user chooses "Move" instead
# of "Delete."
UNMATCHED_DIR="/home/pi/RetroPie/custom_scripts/unmatched_media_files"

# We'll store the list of unreferenced files in a global array
declare -a UNMATCHED_FILES=()

# 1) Gather referenced paths from <image> and <video> in gamelist.xml
#    Unescape &amp; => &
gather_referenced_paths() {
  local gamelist_file="$1"
  local -n ref_images=$2    # Pass-by-reference to fill arrays
  local -n ref_videos=$3

  ref_images=()
  ref_videos=()

  # Find all <image> tags
  while IFS= read -r image_path; do
    # Convert &amp; => &
    image_path="$(echo "$image_path" | sed 's|\&amp;|&|g')"
    # Remove leading "./"
    image_path="${image_path#./}"
    ref_images+=( "$image_path" )
  done < <(grep -oP '(?<=<image>).*?(?=</image>)' "$gamelist_file")

  # Find all <video> tags
  while IFS= read -r video_path; do
    video_path="$(echo "$video_path" | sed 's|\&amp;|&|g')"
    video_path="${video_path#./}"
    ref_videos+=( "$video_path" )
  done < <(grep -oP '(?<=<video>).*?(?=</video>)' "$gamelist_file")
}

# 2) Process a single system folder (like ~/RetroPie/roms/nes),
#    parse its gamelist.xml, gather unreferenced images/videos.
process_system_folder() {
  local system_dir="$1"
  local gamelist="$system_dir/gamelist.xml"
  
  # 1) Remove orphaned media if the ROM is missing
  remove_orphaned_media_for_missing_roms "$system_dir"

  if [ ! -f "$gamelist" ]; then
    log_action "No gamelist.xml in $system_dir; skipping."
    return
  fi

  local -a IMAGES_IN_GAMELIST
  local -a VIDEOS_IN_GAMELIST
  gather_referenced_paths "$gamelist" IMAGES_IN_GAMELIST VIDEOS_IN_GAMELIST
  
  log_action "DEBUG: Found ${#IMAGES_IN_GAMELIST[@]} images and ${#VIDEOS_IN_GAMELIST[@]} videos in $gamelist"
  for img in "${IMAGES_IN_GAMELIST[@]}"; do
    log_action "DEBUG:   image -> $img"
  done
  for vid in "${VIDEOS_IN_GAMELIST[@]}"; do
    log_action "DEBUG:   video -> $vid"
  done

  local images_path="$system_dir/media/images"
  local videos_path="$system_dir/media/videos"

  # Check images
  if [ -d "$images_path" ]; then
    while IFS= read -r file; do
      # e.g. "media/images/Contra.png"
      local rel_path="${file#"$system_dir/"}"
      if [[ ! " ${IMAGES_IN_GAMELIST[*]} " =~ " $rel_path " ]]; then
        UNMATCHED_FILES+=( "$file" )
      fi
    done < <(find "$images_path" -type f)
  fi

  # Check videos
  if [ -d "$videos_path" ]; then
    while IFS= read -r file; do
      local rel_path="${file#"$system_dir/"}"
      if [[ ! " ${VIDEOS_IN_GAMELIST[*]} " =~ " $rel_path " ]]; then
        UNMATCHED_FILES+=( "$file" )
      fi
    done < <(find "$videos_path" -type f)
  fi

}

# 3) Summarize unmatched files, ask user what to do (Delete/Move/Skip)
finalize_unmatched_files() {
  local count=${#UNMATCHED_FILES[@]}
  if [ "$count" -eq 0 ]; then
    dialog --msgbox "No unreferenced media files found!" 10 50
    return 0
  fi

  # Show a short preview in a dialog
  local preview_limit=10
  local msg="Found $count unreferenced media files.\n\n"
  msg+="(Showing up to $preview_limit lines)\n\n"
  for (( i=0; i<"$count" && i<"$preview_limit"; i++ )); do
    msg+="${UNMATCHED_FILES[$i]}\n"
  done

  # Calculate total size
  local tmpfile
  tmpfile=$(mktemp)
  printf "%s\n" "${UNMATCHED_FILES[@]}" > "$tmpfile"
  local total_size
  total_size=$(du -ch --files0-from=<(tr '\n' '\0' < "$tmpfile") | tail -n1)
  rm -f "$tmpfile"
  msg+="\nTotal size: $total_size\n"

  dialog --msgbox "$msg" 20 80

  # Show menu for Delete/Move/Skip
  local choice
  choice=$(dialog --stdout --title "Unreferenced Media" --menu "Choose an action:" 15 60 3 \
    1 "Delete them permanently" \
    2 "Move them to $UNMATCHED_DIR" \
    3 "Skip - Do nothing")
  if [ $? -ne 0 ]; then
    dialog --msgbox "No action taken." 10 50
    return
  fi

  case "$choice" in
    1) confirm_delete ;;
    2) confirm_move ;;
    *) dialog --msgbox "Skipped. No changes made." 10 50 ;;
  esac
}

# 4) Confirm & perform deletion
confirm_delete() {
  local c=${#UNMATCHED_FILES[@]}
  if ! dialog --yesno "Are you sure you want to DELETE $c files permanently?" 10 60; then
    dialog --msgbox "Deletion canceled." 10 50
    return
  fi

  if [ "$DRY_RUN" -eq 1 ]; then
    dialog --msgbox "DRY_RUN=1: Would have deleted $c files, but not deleting now." 10 50
    return
  fi

  local deleted=0
  for f in "${UNMATCHED_FILES[@]}"; do
    if [ -f "$f" ]; then
      rm -f "$f"
      ((deleted++))
      log_action "Deleted unreferenced file: $f"
    fi
  done

  dialog --msgbox "Successfully deleted $deleted files." 10 50
}

# 5) Confirm & perform moving (quarantine)
confirm_move() {
  local c=${#UNMATCHED_FILES[@]}
  if ! dialog --yesno "Are you sure you want to MOVE $c files to:\n$UNMATCHED_DIR?" 12 60; then
    dialog --msgbox "Moving canceled." 10 50
    return
  fi

  if [ "$DRY_RUN" -eq 1 ]; then
    dialog --msgbox "DRY_RUN=1: Would have moved $c files, but not moving now." 10 50
    return
  fi

  local moved=0
  for f in "${UNMATCHED_FILES[@]}"; do
    if [ -f "$f" ]; then
      local rel="${f#/home/pi/}"
      local target="$UNMATCHED_DIR/$rel"
      mkdir -p "$(dirname "$target")"
      mv "$f" "$target"
      log_action "Moved unreferenced file: $f => $target"
      ((moved++))
    fi
  done

  dialog --msgbox "Successfully moved $moved files to:\n$UNMATCHED_DIR." 10 60
}

# 6) The main function for unreferenced media cleanup
#    Displays a progress gauge while scanning each system folder
cleanup_unreferenced_media() {
  # Quick info to user
  dialog --infobox "Searching for unused media...\nThis could take a while.\nPlease do not touch the arcade." 7 50
  sleep 1

  UNMATCHED_FILES=()

  # Count how many system folders (for the gauge)
  local -a systems
  systems=("/home/pi/RetroPie/roms"/*)
  local total_systems=0
  for d in "${systems[@]}"; do
    [ -d "$d" ] && ((total_systems++))
  done

  local processed=0
  for system_dir in "${systems[@]}"; do
    [ -d "$system_dir" ] || continue
    ((processed++))
    local percent=$(( processed * 100 / total_systems ))
    echo "$percent"
    echo "XXX"
    echo "Scanning $system_dir ($processed/$total_systems)..."
    echo "XXX"

    process_system_folder "$system_dir"
  done | dialog --gauge "Please wait..." 10 60 0

  # Summarize & ask user how to proceed
  finalize_unmatched_files
}

###############################################################################
# EXISTING CLEANUP FUNCTIONS
# (lightgun, spinner, trackball, 4p, pixelcade, hdmi, etc.)
###############################################################################

cleanup_lightgun() {
    log_action "Running cleanup for lightgun files..."

    local LIGHTGUN_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-lightgun.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/setup_lists/lightgun_no_clones.txt"

    if [ -f "$LIGHTGUN_CFG" ]; then
        rm -f "$LIGHTGUN_CFG"
        log_action "Deleted lightgun config file: $LIGHTGUN_CFG"
    else
        log_action "Lightgun config file not found: $LIGHTGUN_CFG"
    fi

    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_lightgun."
        return 1
    fi

    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted lightgun ROM file: $rom_path"
        else
            log_action "Lightgun ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Lightgun cleanup completed."
}

cleanup_spinner() {
    log_action "Running cleanup for spinner files..."

    local SPINNER_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-spinner.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/setup_lists/spinner_no_clones.txt"

    if [ -f "$SPINNER_CFG" ]; then
        rm -f "$SPINNER_CFG"
        log_action "Deleted spinner config file: $SPINNER_CFG"
    else
        log_action "Spinner config file not found: $SPINNER_CFG"
    fi

    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_spinner."
        return 1
    fi

    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted spinner ROM file: $rom_path"
        else
            log_action "Spinner ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Spinner cleanup completed."
}

cleanup_trackball() {
    log_action "Running cleanup for trackball files..."

    local TRACKBALL_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-trackball.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/setup_lists/trackball_no_clones.txt"

    if [ -f "$TRACKBALL_CFG" ]; then
        rm -f "$TRACKBALL_CFG"
        log_action "Deleted trackball config file: $TRACKBALL_CFG"
    else
        log_action "Trackball config file not found: $TRACKBALL_CFG"
    fi

    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_trackball."
        return 1
    fi

    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted trackball ROM file: $rom_path"
        else
            log_action "Trackball ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Trackball cleanup completed."
}

cleanup_4p_collection() {
    log_action "Running cleanup for 4P collection files..."
    local FOURP_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-4p.cfg"

    if [ -f "$FOURP_CFG" ]; then
        rm -f "$FOURP_CFG"
        log_action "Deleted 4P collection file: $FOURP_CFG"
    else
        log_action "4P collection file not found: $FOURP_CFG"
    fi

    log_action "4P collection cleanup completed."
}

cleanup_pixelcade() {
    log_action "Running cleanup for Pixelcade files..."

    local pixelcade_dir="/home/pi/pixelcade"
    local achievements_dir="/opt/retropie/configs/all/emulationstation/scripts/achievements"
    local scripts_dir="/opt/retropie/configs/all/emulationstation/scripts"
    local autostart_file="/opt/retropie/configs/all/autostart.sh"
    local pixelcade_line="cd /home/pi/pixelcade && java -jar pixelweb.jar -b -s &"

    if [ -d "$pixelcade_dir" ]; then
        rm -rf "$pixelcade_dir"
        log_action "Deleted Pixelcade directory: $pixelcade_dir"
    else
        log_action "Pixelcade directory not found: $pixelcade_dir"
    fi

    if [ -d "$achievements_dir" ]; then
        rm -rf "$achievements_dir"
        log_action "Deleted Achievements directory: $achievements_dir"
    else
        log_action "Achievements directory not found: $achievements_dir"
    fi

    local pixelcade_files_found=false
    while IFS= read -r file; do
        rm -f "$file"
        log_action "Deleted Pixelcade script file: $file"
        pixelcade_files_found=true
    done < <(find "$scripts_dir" -type f \( -name "01-pixelcade.sh" -o -name "01-pixelcade.sh.test" \) 2>/dev/null)

    if [ "$pixelcade_files_found" = false ]; then
        log_action "No Pixelcade script files found in $scripts_dir"
    fi

    if grep -qF "$pixelcade_line" "$autostart_file"; then
        sed -i "\|$pixelcade_line|d" "$autostart_file"
        log_action "Removed Pixelcade autostart line from $autostart_file"
    else
        log_action "Pixelcade autostart line not found in $autostart_file"
    fi

    log_action "Pixelcade cleanup completed."
}

configure_hdmi_for_retrobase() {
    log_action "Configuring /boot/config.txt for RETROBASE (2P or 4P)..."

    sudo sed -i 's|^hdmi_group=2|hdmi_group=1|' /boot/config.txt
    sudo sed -i 's|^hdmi_mode=82|#hdmi_mode=82|' /boot/config.txt
    sudo sed -i 's|^hdmi_cvt=1920 1080 75 3 0 0 0|#hdmi_cvt=1920 1080 75 3 0 0 0|' /boot/config.txt
    sudo sed -i 's|^#hdmi_drive=2|hdmi_drive=2|' /boot/config.txt
    sudo sed -i 's|^hdmi_force_hotplug=.*|hdmi_force_hotplug=1|' /boot/config.txt

    local ES_SETTINGS="/opt/retropie/configs/all/emulationstation/es_settings.cfg"
    if [ -f "$ES_SETTINGS" ]; then
        log_action "Changing AudioDevice to HDMI in $ES_SETTINGS"
        sudo sed -i 's|<string name="AudioDevice" value="Headphone" />|<string name="AudioDevice" value="HDMI" />|' "$ES_SETTINGS"
    else
        log_action "Could not find $ES_SETTINGS to update AudioDevice."
    fi

    log_action "Finished configuring HDMI output and audio device for RETROBASE."
}

########################################################
# remove_orphaned_media_for_missing_roms()
# Checks each <game> in gamelist.xml:
#  - If the <path> file (the ROM) is missing,
#  - Then remove the <image>/<video> files, but DO NOT
#    remove the <game> block from the gamelist.
# 
# This complements your unreferenced-media check by
# cleaning up media for games that the user never
# removed from gamelist.xml but did physically delete
# the ROM file.
########################################################
remove_orphaned_media_for_missing_roms() {
    local system_dir="$1"
    local gamelist="$system_dir/gamelist.xml"

    # If there's no gamelist.xml, skip
    if [ ! -f "$gamelist" ]; then
        log_action "No gamelist.xml in $system_dir; skipping orphan check for missing ROMs."
        return
    fi

    # We'll parse <game> blocks, extracting <path>, <image>, <video>.
    # This approach uses `awk` to grab lines from <game>... </game>.

    local game_block=""
    awk '/<game /,/<\/game>/' "$gamelist" | while IFS= read -r line; do
        game_block+="$line"$'\n'

        if [[ "$line" =~ "</game>" ]]; then
            # We have one entire <game> block in $game_block
            local rom_path image_path video_path

            # Extract <path>, <image>, <video> lines (if present)
            rom_path="$(echo "$game_block"   \
                | grep -oP '(?<=<path>).*?(?=</path>)'   \
                | head -n1)"
            image_path="$(echo "$game_block" \
                | grep -oP '(?<=<image>).*?(?=</image>)' \
                | head -n1)"
            video_path="$(echo "$game_block" \
                | grep -oP '(?<=<video>).*?(?=</video>)' \
                | head -n1)"

            # Unescape &amp; => &
            rom_path="$(echo "$rom_path"       | sed 's|\&amp;|&|g')"
            image_path="$(echo "$image_path"   | sed 's|\&amp;|&|g')"
            video_path="$(echo "$video_path"   | sed 's|\&amp;|&|g')"

            # Remove leading "./" if any
            rom_path="${rom_path#./}"
            image_path="${image_path#./}"
            video_path="${video_path#./}"

            # If the ROM file doesn't exist, remove the associated images/videos
            if [ -n "$rom_path" ]; then
                local full_rom_path="$system_dir/$rom_path"
                if [ ! -f "$full_rom_path" ]; then
                    # Orphaned: The ROM is missing
                    log_action "ORPHANED GAME: Missing ROM '$full_rom_path'. Removing image/video files..."

                    # Remove the image if it exists
                    if [ -n "$image_path" ]; then
                        local full_img="$system_dir/$image_path"
                        if [ -f "$full_img" ]; then
                            log_action "Deleting orphaned image: $full_img"
                            [ "$DRY_RUN" -eq 1 ] || rm -f "$full_img"
                        fi
                    fi

                    # Remove the video if it exists
                    if [ -n "$video_path" ]; then
                        local full_vid="$system_dir/$video_path"
                        if [ -f "$full_vid" ]; then
                            log_action "Deleting orphaned video: $full_vid"
                            [ "$DRY_RUN" -eq 1 ] || rm -f "$full_vid"
                        fi
                    fi
                fi
            fi

            # Reset block for next <game>
            game_block=""
        fi
    done
}

###############################################################################
# ADD A PROGRESS BAR TO SETUP_ARCADE_MODEL
###############################################################################
setup_arcade_model() {
    if [ -f "$MARKER_FILE" ]; then
        local configured_model
        configured_model=$(cat "$MARKER_FILE")
        dialog --msgbox "Arcade already configured for $configured_model. Returning to menu." 10 50
        return
    fi

    local arcade_model
    arcade_model=$(dialog --stdout --title "Choose Arcade Model" --menu "Select the arcade model to configure:" 15 50 6 \
        1 "RETROBASE-2P" \
        2 "RETROBASE-4P" \
        3 "MINICADE-25" \
        4 "MINICADE-32" \
        5 "MEGACADE-2P" \
        6 "MEGACADE-4P")

    if [ $? -ne 0 ]; then
        log_action "User canceled arcade model selection."
        return
    fi

    if [ -z "$arcade_model" ]; then
        log_action "No arcade model selected."
        return
    fi

    local selected_model
    case $arcade_model in
        1) selected_model="RETROBASE-2P" ;;
        2) selected_model="RETROBASE-4P" ;;
        3) selected_model="MINICADE-25" ;;
        4) selected_model="MINICADE-32" ;;
        5) selected_model="MEGACADE-2P" ;;
        6) selected_model="MEGACADE-4P" ;;
        *)
            dialog --msgbox "Invalid selection. Returning to menu." 10 50
            log_action "Invalid arcade model selection: $arcade_model"
            return
            ;;
    esac

    dialog --yesno "You have selected '$selected_model'. Do you want to proceed?" 10 50
    if [ $? -ne 0 ]; then
        log_action "User chose not to proceed with arcade model setup for $selected_model."
        return
    fi

    log_action "User confirmed arcade model selection: $selected_model"

    # We'll define an array of steps and run them with a gauge
    local -a steps=()

    case $selected_model in
        "RETROBASE-2P")
            steps=("cleanup_4p_collection" "cleanup_lightgun" "cleanup_spinner" "cleanup_trackball" "cleanup_pixelcade" "configure_hdmi_for_retrobase")
            ;;
        "RETROBASE-4P")
            steps=("cleanup_lightgun" "cleanup_spinner" "cleanup_trackball" "cleanup_pixelcade" "configure_hdmi_for_retrobase")
            ;;
        "MINICADE-25")
            steps=("cleanup_4p_collection" "cleanup_lightgun" "cleanup_spinner" "cleanup_trackball" "cleanup_pixelcade")
            ;;
        "MINICADE-32")
            steps=("cleanup_lightgun" "cleanup_pixelcade")
            ;;
        "MEGACADE-2P")
            steps=("cleanup_lightgun" "cleanup_pixelcade")
            ;;
        "MEGACADE-4P")
            steps=("cleanup_lightgun" "cleanup_spinner" "cleanup_trackball" "cleanup_pixelcade")
            ;;
    esac

    (
      local total=${#steps[@]}
      local i=0
      for func_name in "${steps[@]}"; do
          i=$((i+1))
          local percent=$(( i * 100 / total ))
          echo "$percent"
          echo "XXX"
          echo "Running $func_name ($i/$total)"
          echo "XXX"

          # Execute the function
          $func_name
      done
    ) | dialog --gauge "Configuring $selected_model. Please wait..." 10 60 0

    echo "$selected_model" > "$MARKER_FILE"
    log_action "Arcade model setup completed for $selected_model. Marker file created."
    dialog --msgbox "Arcade model setup for $selected_model completed successfully!" 10 50
}

###############################################################################
# ADD A PROGRESS BAR TO CLEAR_LAST_PLAYED_DATA
###############################################################################
clear_last_played_data() {
    local any_changes=false
    local gamelists=()

    while IFS= read -r file; do
        gamelists+=("$file")
    done < <(find /home/pi/RetroPie/roms -type f -name "gamelist.xml")

    gamelists+=("/opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml")

    # We'll show a gauge
    (
      local total=${#gamelists[@]}
      local i=0

      if [ "$total" -eq 0 ]; then
        echo "0"
        echo "XXX"
        echo "No gamelists found."
        echo "XXX"
        exit 0
      fi

      for gamelist in "${gamelists[@]}"; do
        i=$((i+1))
        local percent=$(( i * 100 / total ))
        echo "$percent"
        echo "XXX"
        echo "Processing: $gamelist ($i/$total)"
        echo "XXX"

        if [ -f "$gamelist" ] && grep -qE '<lastplayed>|<playcount>' "$gamelist"; then
            sed -i '/<lastplayed>/d; /<playcount>/d' "$gamelist"
            log_action "Cleared lastplayed/playcount in $gamelist"
            any_changes=true
        fi
      done
    ) | dialog --gauge "Clearing last played data..." 10 60 0

    if $any_changes; then
        dialog --msgbox "Last played data cleared." 10 50
    else
        dialog --msgbox "No last played data found." 10 50
    fi
}

toggle_ui_mode() {
    local ui_file="$EMULATIONSTATION_CONFIG/es_settings.cfg"
    local current_mode
    local current_save_mode

    if grep -q '<string name="UIMode" value="Kiosk" />' "$ui_file"; then
        current_mode="Kiosk"
    elif grep -q '<string name="UIMode" value="Full" />' "$ui_file"; then
        current_mode="Full"
    else
        dialog --msgbox "Unable to determine current UI mode. Exiting." 10 50
        log_action "Failed to determine current UI mode from $ui_file"
        return
    fi

    if grep -q '<string name="SaveGamelistsMode" value="always" />' "$ui_file"; then
        current_save_mode="always"
    elif grep -q '<string name="SaveGamelistsMode" value="never" />' "$ui_file"; then
        current_save_mode="never"
    else
        dialog --msgbox "Unable to determine current SaveGamelistsMode. Exiting." 10 50
        log_action "Failed to determine current SaveGamelistsMode from $ui_file"
        return
    fi

    dialog --yesno "Current UI mode is: $current_mode.\nCurrent SaveGamelistsMode is: $current_save_mode.\n\nDo you want to toggle to the other mode?" 10 50
    if [ $? -ne 0 ]; then
        log_action "User chose not to toggle UI mode. Current mode: $current_mode"
        return
    fi

    local new_mode
    local new_save_mode
    if [ "$current_mode" == "Kiosk" ]; then
        new_mode="Full"
        new_save_mode="never"
    else
        new_mode="Kiosk"
        new_save_mode="always"
    fi

    sudo sed -i "s|<string name=\"UIMode\" value=\"$current_mode\" />|<string name=\"UIMode\" value=\"$new_mode\" />|" "$ui_file"
    sudo sed -i "s|<string name=\"SaveGamelistsMode\" value=\"$current_save_mode\" />|<string name=\"SaveGamelistsMode\" value=\"$new_save_mode\" />|" "$ui_file"

    if grep -q "<string name=\"UIMode\" value=\"$new_mode\" />" "$ui_file" && grep -q "<string name=\"SaveGamelistsMode\" value=\"$new_save_mode\" />" "$ui_file"; then
        dialog --msgbox "UI mode changed to: $new_mode\nSaveGamelistsMode changed to: $new_save_mode\n\nA reboot is required for changes to take effect." 10 50
        log_action "Toggled UI mode from $current_mode to $new_mode and SaveGamelistsMode from $current_save_mode to $new_save_mode"
    else
        dialog --msgbox "Failed to change UI mode to: $new_mode or SaveGamelistsMode to: $new_save_mode." 10 50
        log_action "Failed to change UI mode from $current_mode to $new_mode or SaveGamelistsMode from $current_save_mode to $new_save_mode"
    fi
}

test_controls() {
    log_action "Test controls initiated."
    python3 /home/pi/RetroPie/roms/tools/control_tester.py > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_action "Control tester script exited successfully."
    else
        log_action "Control tester script encountered an error."
    fi
}

reboot_system() {
    log_action "System reboot initiated."
    sudo killall -SIGTERM emulationstation || true
    sudo reboot
}

advanced_setup() {
    while true; do
        ADV_OPTION=$(dialog --stdout --title "Advanced Setup" --menu "Select a cleanup option:" 15 60 7 \
            1 "Remove 4P Collection" \
            2 "Remove Lightgun Games & Menu Collection" \
            3 "Remove Trackball Games & Menu Collections" \
            4 "Remove Spinner Games & Menu Collections" \
            5 "Remove Pixelcade Functionality & Files" \
            6 "Switch to HDMI audio for RetroBase" \
            7 "Return to Main Menu")

        adv_exit_status=$?
        if [ $adv_exit_status -ne 0 ]; then
            log_action "User canceled the Advanced Setup menu."
            break
        fi

        case $ADV_OPTION in
            1)
                if dialog --yesno "Are you sure you want to remove the 4P Collection?" 10 50; then
                    cleanup_4p_collection
                else
                    log_action "User canceled removal of 4P Collection."
                fi
                ;;
            2)
                if dialog --yesno "Are you sure you want to remove Lightgun Games & Menu Collection?" 10 60; then
                    cleanup_lightgun
                else
                    log_action "User canceled removal of Lightgun Games & Menu Collection."
                fi
                ;;
            3)
                if dialog --yesno "Are you sure you want to remove Trackball Games & Menu Collections?" 10 60; then
                    cleanup_trackball
                else
                    log_action "User canceled removal of Trackball Games & Menu Collections."
                fi
                ;;
            4)
                if dialog --yesno "Are you sure you want to remove Spinner Games & Menu Collections?" 10 60; then
                    cleanup_spinner
                else
                    log_action "User canceled removal of Spinner Games & Menu Collections."
                fi
                ;;
            5)
                if dialog --yesno "Are you sure you want to remove Pixelcade Functionality & Files?" 10 60; then
                    cleanup_pixelcade
                else
                    log_action "User canceled removal of Pixelcade Functionality & Files."
                fi
                ;;
            6)
                if dialog --yesno "Are you sure you want to switch to HDMI audio for RetroBase models?" 10 60; then
                    configure_hdmi_for_retrobase
                else
                    log_action "User canceled switching audio to HDMI for Retrobase models."
                fi
                ;;
            7)
                log_action "User chose to return to the Main Menu from Advanced Setup."
                break
                ;;
            *)
                log_action "Invalid selection in Advanced Setup: $ADV_OPTION"
                dialog --msgbox "Invalid selection. Please try again." 10 50
                ;;
        esac
    done
}

# MAIN MENU
while true; do
	OPTION=$(dialog --stdout --title "Arcade Setup Menu" --menu "Select an option:" 15 50 8 \
		1 "Setup Arcade Model" \
		2 "Clear Last Played Data" \
		3 "Toggle EmulationStation UI Mode" \
		4 "Test Controls" \
		5 "Reboot System" \
		6 "Advanced Setup" \
		7 "Delete Unmatched ROM Media Files" \
        8 "Exit")

    menu_exit_status=$?
    if [ $menu_exit_status -ne 0 ]; then
        log_action "User canceled the main menu. Exiting."
        dialog --msgbox "Exiting setup menu. Please test system prior to shipment." 10 50
        rm -f "$LOCKFILE"
        exit 0
    fi

    case $OPTION in
        1) setup_arcade_model ;;
        2) clear_last_played_data ;;
        3) toggle_ui_mode ;;
        4) test_controls ;;
        5) reboot_system ;;
        6) advanced_setup ;;
        7) cleanup_unreferenced_media ;;
        8)
            log_action "Exiting setup menu."
            dialog --msgbox "Exiting setup menu. Please test system prior to shipment." 10 50
            rm -f "$LOCKFILE"
            exit 0
            ;;            
        *)
            log_action "Invalid selection. Exiting setup menu."
            dialog --msgbox "Invalid selection. Exiting setup menu." 10 50
            rm -f "$LOCKFILE"
            exit 0
            ;;
    esac
done